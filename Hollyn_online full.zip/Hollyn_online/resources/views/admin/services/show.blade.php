@extends('admin.layout')
@section('title','Service #'.$service->id)

@section('content')
<div class="flex items-center justify-between mb-6">
  <h1 class="text-2xl font-semibold">Service #{{ $service->id }}</h1>
  <div class="flex gap-2">
    <form method="post" action="{{ route('admin.services.reprovision',$service) }}">@csrf
      <button class="px-3 py-2 rounded-lg border">Re-provision</button>
    </form>
    @if($service->status!=='active')
      <form method="post" action="{{ route('admin.services.activate',$service) }}">@csrf
        <button class="px-3 py-2 rounded-lg border text-emerald-700">Activate</button>
      </form>
    @else
      <form method="post" action="{{ route('admin.services.suspend',$service) }}">@csrf
        <button class="px-3 py-2 rounded-lg border text-amber-700">Suspend</button>
      </form>
    @endif
    <form method="post" action="{{ route('admin.services.sendCredentials',$service) }}">@csrf
      <button class="px-3 py-2 rounded-lg border">Send Credentials</button>
    </form>
  </div>
</div>

@php
  $status = $service->status ?? 'provisioning';
  $badge  = match($status) {
    'active'       => 'bg-emerald-50 text-emerald-700',
    'provisioning' => 'bg-amber-50 text-amber-700',
    'suspended'    => 'bg-rose-50 text-rose-700',
    default        => 'bg-gray-200 text-gray-700',
  };
@endphp

<div class="grid lg:grid-cols-2 gap-5">
  <div class="card">
    <div class="text-sm text-slate-500 mb-2">Details</div>
    <div class="space-y-1 text-sm">
      <div><span class="text-slate-500">User:</span> {{ optional(optional($service->order)->user)->name ?? '—' }}</div>
      <div><span class="text-slate-500">Plan:</span> {{ optional($service->plan)->name ?? '—' }}</div>
      <div><span class="text-slate-500">Domain:</span> {{ $service->domain ?? '—' }}</div>
      <div><span class="text-slate-500">Username:</span> {{ $service->panel_username ?? '—' }}</div>
      <div><span class="text-slate-500">Enduser URL:</span>
        @php $panel = $service->enduser_url ?? config('services.webuzo.enduser_url'); @endphp
        @if($panel)
          <a href="{{ $panel }}" target="_blank" class="text-blue-600 hover:underline">{{ $panel }}</a>
        @else
          —
        @endif
      </div>
      <div><span class="text-slate-500">Status:</span>
        <span class="px-2 py-0.5 rounded-full text-xs font-semibold {{ $badge }}">
          {{ ucfirst($status) }}
        </span>
      </div>
      <div><span class="text-slate-500">Created:</span> {{ $service->created_at }}</div>
      <div><span class="text-slate-500">Updated:</span> {{ $service->updated_at }}</div>
    </div>
  </div>

  <div class="card">
    <div class="text-sm text-slate-500 mb-2">Order</div>
    @if($service->order)
      <div class="space-y-1 text-sm">
        <div><span class="text-slate-500">Order ID:</span> #{{ $service->order->id }}</div>
        <div><span class="text-slate-500">Status:</span> {{ ucfirst($service->order->status) }}</div>
        <div><span class="text-slate-500">Price:</span> TZS {{ number_format((int)($service->order->price_tzs ?? 0)) }}</div>
        <div><span class="text-slate-500">Created:</span> {{ $service->order->created_at }}</div>
        <div><a class="underline" href="{{ route('admin.orders.show',$service->order) }}">Open order</a></div>
      </div>
    @else
      <div class="text-slate-500">No order linked.</div>
    @endif
  </div>
</div>

{{-- Logs --}}
<div class="card mt-6">
  <div class="flex items-center justify-between">
    <h2 class="text-lg font-semibold text-brand-ocean">Provisioning Logs</h2>
  </div>
  <div class="mt-3 overflow-x-auto">
    <table class="min-w-full text-sm">
      <thead class="bg-slate-50 text-slate-600">
        <tr>
          <th class="px-4 py-3 text-left">ID</th>
          <th class="px-4 py-3 text-left">Step</th>
          <th class="px-4 py-3 text-left">Success</th>
          <th class="px-4 py-3 text-left">Created</th>
          <th class="px-4 py-3 text-left">Request</th>
          <th class="px-4 py-3 text-left">Response</th>
        </tr>
      </thead>
      <tbody>
        @forelse($logs as $log)
        @php
          $okBadge = $log->success ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700';
        @endphp
        <tr class="border-t align-top">
          <td class="px-4 py-3">{{ $log->id }}</td>
          <td class="px-4 py-3">{{ $log->step }}</td>
          <td class="px-4 py-3">
            <span class="px-2 py-0.5 rounded-full text-xs font-semibold {{ $okBadge }}">
              {{ $log->success ? 'Yes' : 'No' }}
            </span>
          </td>
          <td class="px-4 py-3">{{ $log->created_at }}</td>
          <td class="px-4 py-3 whitespace-pre-wrap break-words max-w-[22rem]">
            {{ is_array($log->request) ? json_encode($log->request) : $log->request }}
          </td>
          <td class="px-4 py-3 whitespace-pre-wrap break-words max-w-[22rem]">
            {{ is_array($log->response) ? json_encode($log->response) : $log->response }}
          </td>
        </tr>
        @empty
        <tr><td colspan="6" class="px-4 py-6 text-center text-slate-500">No logs yet.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
  <div class="mt-3">{{ $logs->links() }}</div>
</div>
@endsection
