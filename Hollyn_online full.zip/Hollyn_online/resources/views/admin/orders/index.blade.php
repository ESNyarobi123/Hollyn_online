@extends('admin.layout')
@section('title','Orders')
@section('content')
<div class="flex items-center justify-between mb-6">
  <h1 class="text-2xl font-semibold">Orders</h1>
  <a href="{{ route('admin.orders.create') }}" class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">+ New Order</a>
</div>

<form method="get" class="mb-4 flex gap-3 items-center">
  <select name="status" class="px-3 py-2 border rounded-lg">
    <option value="">All statuses</option>
    @foreach(['pending','paid','failed','active','cancelled'] as $st)
      <option value="{{ $st }}" @selected(request('status')===$st)>{{ ucfirst($st) }}</option>
    @endforeach
  </select>
  <button class="px-4 py-2 rounded-lg border">Filter</button>
</form>

<div class="bg-white border rounded-xl overflow-hidden">
  <table class="min-w-full text-sm">
    <thead class="bg-slate-50 text-slate-600">
      <tr>
        <th class="px-4 py-3 text-left">ID</th>
        <th class="px-4 py-3 text-left">User</th>
        <th class="px-4 py-3 text-left">Plan</th>
        <th class="px-4 py-3 text-left">Price (TZS)</th>
        <th class="px-4 py-3 text-left">Status</th>
        <th class="px-4 py-3 text-left">Created</th>
        <th class="px-4 py-3"></th>
      </tr>
    </thead>
    <tbody>
      @foreach($orders as $o)
      <tr class="border-t">
        <td class="px-4 py-3">{{ $o->id }}</td>
        <td class="px-4 py-3">{{ optional($o->user)->name }}</td>
        <td class="px-4 py-3">{{ optional($o->plan)->name }}</td>
        <td class="px-4 py-3 font-medium">{{ number_format((int)$o->price_tzs) }}</td>
        <td class="px-4 py-3"><span class="px-2 py-1 rounded text-xs bg-slate-100">{{ $o->status }}</span></td>
        <td class="px-4 py-3">{{ $o->created_at }}</td>
        <td class="px-4 py-3 text-right">
          <a class="text-blue-600 hover:underline" href="{{ route('admin.orders.edit',$o) }}">Edit</a>
          <a class="text-slate-600 hover:underline ml-3" href="{{ route('admin.orders.show',$o) }}">View</a>
          <form action="{{ route('admin.orders.destroy',$o) }}" method="post" class="inline" onsubmit="return confirm('Delete order?')">
            @csrf @method('DELETE')
            <button class="text-rose-600 hover:underline ml-3">Delete</button>
          </form>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>

<div class="mt-4">{{ $orders->links() }}</div>
@endsection
