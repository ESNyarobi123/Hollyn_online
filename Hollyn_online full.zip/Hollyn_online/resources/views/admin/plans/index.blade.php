@extends('admin.layout')
@section('title','Plans')
@section('content')
<div class="flex items-center justify-between mb-6">
  <h1 class="text-2xl font-semibold">Plans</h1>
  <a href="{{ route('admin.plans.create') }}" class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">+ New Plan</a>
</div>

<div class="bg-white border rounded-xl overflow-hidden">
  <table class="min-w-full text-sm">
    <thead class="bg-slate-50 text-slate-600">
      <tr>
        <th class="px-4 py-3 text-left">ID</th>
        <th class="px-4 py-3 text-left">Name</th>
        <th class="px-4 py-3 text-left">Price (TZS)</th>
        <th class="px-4 py-3 text-left">Period (months)</th>
        <th class="px-4 py-3 text-left">Active</th>
        <th class="px-4 py-3"></th>
      </tr>
    </thead>
    <tbody>
      @foreach($plans as $p)
      <tr class="border-t">
        <td class="px-4 py-3">{{ $p->id }}</td>
        <td class="px-4 py-3 font-medium">{{ $p->name }}</td>
        <td class="px-4 py-3">{{ number_format((int)$p->price_tzs) }}</td>
        <td class="px-4 py-3">{{ $p->period_months }}</td>
        <td class="px-4 py-3">
          @if($p->is_active)
            <span class="px-2 py-1 rounded text-xs bg-emerald-50 text-emerald-700 border border-emerald-200">Active</span>
          @else
            <span class="px-2 py-1 rounded text-xs bg-slate-100">Inactive</span>
          @endif
        </td>
        <td class="px-4 py-3 text-right">
          <a class="text-blue-600 hover:underline" href="{{ route('admin.plans.edit',$p) }}">Edit</a>
          <a class="text-slate-700 hover:underline ml-3" href="{{ route('admin.plans.show',$p) }}">View</a>
          <form action="{{ route('admin.plans.destroy',$p) }}" method="post" class="inline" onsubmit="return confirm('Delete plan?')">
            @csrf @method('DELETE')
            <button class="text-rose-600 hover:underline ml-3">Delete</button>
          </form>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>

<div class="mt-4">{{ $plans->links() }}</div>
@endsection
