@extends('layouts.app')

@section('content')
<link rel="preload" href="https://unpkg.com/aos@2.3.4/dist/aos.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="https://unpkg.com/aos@2.3.4/dist/aos.css"></noscript>

<style>
  html { scroll-behavior: smooth; }
  @keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
  .animate-marquee { animation: marquee 30s linear infinite; }
  @keyframes testimonial { 0%,20%{transform:translateX(0)}40%,60%{transform:translateX(-50%)}80%,100%{transform:translateX(0)} }
  .animate-testimonial { animation: testimonial 18s ease-in-out infinite; }
  @media (prefers-reduced-motion: reduce) { .animate-marquee, .animate-testimonial { animation: none; } }
</style>

{{-- ===================== HERO (with image) ===================== --}}
<section class="relative overflow-hidden rounded-3xl p-6 sm:p-8 md:p-12 shadow-xl bg-gradient-to-br from-brand-cream/40 via-white to-brand-cream/30 backdrop-blur-sm border border-brand-cream/20">
  <div class="pointer-events-none absolute inset-0 -z-10">
    <div class="absolute -top-24 -left-24 w-72 h-72 rounded-full blur-3xl opacity-20 bg-emerald-400/20"></div>
    <div class="absolute -bottom-24 -right-24 w-80 h-80 rounded-full blur-3xl opacity-20 bg-blue-400/20"></div>
    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 w-[800px] h-px bg-gradient-to-r from-transparent via-brand-slate/10 to-transparent"></div>
  </div>

  <div class="relative z-10 max-w-6xl mx-auto grid lg:grid-cols-2 gap-8 items-center">
    {{-- KUSHOTO: maandishi --}}
    <div class="text-center sm:text-left">
      <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold bg-brand-gold/10 text-brand-gold border border-brand-gold/20" data-aos="fade-down">
        Hollyn Hosting <span class="opacity-70">•</span> TZ Ready
      </span>
      <h1 class="mt-4 text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight text-brand-ocean tracking-tight" data-aos="fade-up" data-aos-delay="100">
        Host faster. Scale smarter. <span class="text-brand-emerald">Go live</span> in minutes.
      </h1>
      <p class="mt-4 text-brand-slate max-w-2xl mx-auto sm:mx-0" data-aos="fade-up" data-aos-delay="200">
        Simple checkout na ZenoPay. Auto-provision ya <b>Webuzo</b> — unapata cPanel link papo hapo bila kusubiri.
      </p>
      <div class="mt-6 flex flex-col sm:flex-row justify-center sm:justify-start gap-3" data-aos="zoom-in" data-aos-delay="300">
        <a href="{{ route('plans') }}" class="btn-primary px-6 py-3">View Plans</a>
        @guest <a href="{{ route('register') }}" class="btn-gold px-6 py-3">Create Account</a> @endguest
        <a href="#features" class="btn-ghost px-6 py-3">See Features</a>
      </div>

      <div class="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm" data-aos="fade-up" data-aos-delay="400">
        @foreach([['99.9','Uptime SLA'],['24','/7 Support'],['1','Click Installer'],['300+','Apps']] as $stat)
          <div class="bg-white/60 backdrop-blur-sm rounded-xl p-4 flex flex-col items-center sm:items-start gap-2 border border-brand-cream/30">
            <div class="text-brand-emerald text-2xl font-extrabold" data-counter data-val="{{ $stat[0] }}">0</div>
            <span class="text-brand-slate text-center sm:text-left">{{ $stat[1] }}</span>
          </div>
        @endforeach
      </div>
    </div>

    {{-- KULIA: picha ya web hosting/datacenter --}}
    <div class="relative" data-aos="fade-left" data-aos-delay="150" aria-hidden="true">
      {{-- Picha kuu: racks/servers (Unsplash) --}}
      <img
        src="https://www.knownhost.com/blog/wp-content/uploads/2020/02/Web-Hosting-Info-Graphic-1024x536.png"
        alt="Server racks na miundombinu ya web hosting"
        class="w-full h-72 sm:h-80 md:h-[22rem] object-cover rounded-2xl border border-brand-cream/40 shadow-xl"
        loading="lazy"
        width="1400" height="880">

      {{-- Picha ndogo ya ziada: “control panel/graphs” --}}
      {{-- <img
        src="https://images.unsplash.com/photo-1518779578993-ec3579fee39f?q=80&w=900&auto=format&fit=crop"
        alt="Dashboard ya paneli na metrics za tovuti"
        class="hidden sm:block absolute -bottom-6 -left-6 w-40 sm:w-48 md:w-56 aspect-[4/3] object-cover rounded-xl border border-white shadow-lg"
        loading="lazy"
        width="900" height="600"> --}}
    </div>
  </div>
</section>

{{-- ===================== TRUST MARQUEE ===================== --}}
<section class="mt-12" aria-label="Trusted by">
  <div class="overflow-hidden rounded-2xl bg-white/60 backdrop-blur-sm border border-brand-cream/20 py-3">
    <div class="flex items-center gap-8 animate-marquee whitespace-nowrap">
      @php $logos = ['WordPress','Laravel','Node','phpMyAdmin','NGINX','MySQL','Redis','Cloudflare']; @endphp
      @foreach(array_merge($logos, $logos) as $logo)
        <span class="text-brand-slate font-medium text-lg px-4 py-2">{{ $logo }}</span>
      @endforeach
    </div>
  </div>
</section>


{{-- ===================== FEATURED PLANS (MODERN PRICING CARDS) ===================== --}}
<section class="mt-16">
  <div class="text-center mb-12">
    <h2 class="heading" data-aos="fade-up">Featured Plans</h2>
  </div>

  @if($plans->isEmpty())
    <div class="card text-center py-12" data-aos="fade-up">
      <p>No plans yet. <a href="{{ route('admin.plans.index') }}" class="text-brand-emerald hover:underline">Add plans in admin</a>.</p>
    </div>
  @else
    <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
      @foreach($plans as $index => $p)
        <div class="relative group rounded-2xl overflow-hidden border border-brand-cream/30 bg-white transition-all duration-300 hover:shadow-xl hover:-translate-y-1" data-aos="zoom-in" data-aos-delay="{{ $index * 100 }}">
          @if($loop->first)
            <div class="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-brand-emerald text-white text-xs font-bold px-3 py-1 rounded-full z-10">
              Most Popular
            </div>
          @endif

          <div class="p-6">
            <div class="text-xs uppercase tracking-wide text-brand-slate font-medium">{{ $p->slug }}</div>
            <h3 class="mt-1 text-xl font-bold text-brand-ocean">{{ $p->name }}</h3>
            <div class="mt-3">
              <span class="text-3xl font-extrabold text-brand-emerald">TZS {{ number_format($p->price_tzs) }}</span>
              <span class="text-brand-slate ml-1">/mo</span>
            </div>

            @php
              $features = collect(explode("\n", (string)($p->features ?? '')))
                ->filter(fn($l) => trim($l) !== '')
                ->take(5);
            @endphp

            @if($features->isNotEmpty())
              <ul class="mt-5 space-y-3">
                @foreach($features as $f)
                  <li class="flex items-start gap-2 text-sm text-brand-slate">
                    <svg class="flex-shrink-0 mt-0.5 w-4 h-4 text-brand-emerald" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>{{ trim($f) }}</span>
                  </li>
                @endforeach
              </ul>
            @endif

            <a href="{{ route('checkout.show', $p) }}" class="mt-6 w-full btn-primary py-2.5 text-center block">Order {{ $p->name }}</a>
          </div>
        </div>
      @endforeach
    </div>
  @endif
</section>
{{-- ===================== WHY CHOOSE US (3x2 GRID - MODERN CARDS) ===================== --}}
<section id="features" class="mt-16">
  <div class="text-center max-w-3xl mx-auto mb-12">
    <h2 class="heading" data-aos="fade-up">Why Choose Hollyn</h2>
    <p class="text-brand-slate mt-4" data-aos="fade-up" data-aos-delay="100">
      Tumejenga hosting inayoweka kipaumbele <b>kasi</b>, <b>urahisi</b> na <b>uaminifu</b> kwa biashara yako.
    </p>
  </div>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    @php
      $features = [
        ['title' => 'Auto-Provision Webuzo', 'desc' => 'Baada ya malipo, akaunti inatengenezwa kiotomatiki na cPanel/Webuzo link inapatikana mara moja.', 'color' => 'from-emerald-500/10 to-emerald-400/5', 'icon' => 'M5 12l4 4L19 6'],
        ['title' => 'Security First', 'desc' => 'Free SSL, isolates, firewalls na updates za mara kwa mara ili kuweka tovuti salama.', 'color' => 'from-blue-500/10 to-blue-400/5', 'icon' => 'M12 20s8-4 8-10a8 8 0 10-16 0c0 6 8 10 8 10z'],
        ['title' => '1-Click Apps', 'desc' => 'WordPress, Laravel starters, phpMyAdmin, Node runtimes — weka na ubofyo mmoja.', 'color' => 'from-amber-500/10 to-amber-400/5', 'icon' => 'M3 7h18M3 12h14M3 17h10'],
        ['title' => 'Scalable by Design', 'desc' => 'Anza na Lite, panua hadi Boost/Grow/Max bila downtime — bili ni rahisi, wazi.', 'color' => 'from-violet-500/10 to-violet-400/5', 'icon' => 'M4 4h16v8H4zM10 12v8'],
        ['title' => 'Backups & Restore', 'desc' => 'Snapshots za kila siku + restore point-in-time ili uwe na amani ya moyo.', 'color' => 'from-rose-500/10 to-rose-400/5', 'icon' => 'M4 6h16M4 12h12M4 18h8'],
        ['title' => 'TZ Local Payments', 'desc' => 'ZenoPay & mobile money — lipa haraka, pokea huduma mara moja.', 'color' => 'from-green-500/10 to-green-400/5', 'icon' => 'M8 21V3l13 9-13 9z'],
      ];
    @endphp

    @foreach($features as $i => $f)
      <div class="group relative overflow-hidden rounded-2xl bg-gradient-to-br {{ $f['color'] }} p-6 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border border-white/20 backdrop-blur-sm" data-aos="fade-up" data-aos-delay="{{ $i * 100 }}">
        <div class="flex items-start gap-4">
          <div class="p-3 rounded-xl bg-white/80 shadow-sm">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" class="text-brand-ocean">
              <path d="{{ $f['icon'] }}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div>
            <h3 class="font-bold text-brand-ocean text-lg">{{ $f['title'] }}</h3>
            <p class="mt-2 text-brand-slate text-sm">{{ $f['desc'] }}</p>
          </div>
        </div>
        <div class="absolute bottom-0 right-0 w-24 h-24 rounded-full bg-current opacity-5 -z-0"></div>
      </div>
    @endforeach
  </div>
</section>


{{-- ===================== TABS ===================== --}}
<section class="mt-16">
  <div class="card p-6 rounded-2xl">
    <div class="flex flex-wrap gap-2 mb-6" role="tablist">
      <button class="btn-ghost tab-btn px-4 py-2" data-tab="tab-compare" role="tab">Quick Comparison</button>
      <button class="btn-ghost tab-btn px-4 py-2" data-tab="tab-onboard" role="tab">How Onboarding Works</button>
    </div>

    <div id="tab-compare" class="tab-pane">
      <div class="overflow-x-auto">
        <table class="w-full text-sm">
          <thead>
            <tr class="border-b border-brand-cream/30">
              <th class="text-left p-3 font-semibold text-brand-ocean">Plan</th>
              <th class="text-left p-3">Storage</th>
              <th class="text-left p-3">Bandwidth</th>
              <th class="text-left p-3">Domains</th>
              <th class="text-left p-3">Support</th>
            </tr>
          </thead>
          <tbody>
            @foreach([
              ['Hollyn Lite', '20 GB SSD', 'Unmetered (Fair Use)', '1', 'Email'],
              ['Hollyn Boost', '40 GB SSD', 'Unmetered', '3', 'Priority Email'],
              ['Hollyn Grow', '80 GB NVMe', 'Unmetered', '5', 'Email + Chat'],
              ['Hollyn Max', '160 GB NVMe', 'Unmetered', 'Unlimited', '24/7 Priority'],
            ] as $plan)
              <tr class="border-b border-brand-cream/20 hover:bg-brand-cream/10">
                <td class="p-3 font-semibold text-brand-ocean">{{ $plan[0] }}</td>
                <td class="p-3">{{ $plan[1] }}</td>
                <td class="p-3">{{ $plan[2] }}</td>
                <td class="p-3">{{ $plan[3] }}</td>
                <td class="p-3">{{ $plan[4] }}</td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>

    <div id="tab-onboard" class="tab-pane hidden">
      <ol class="relative border-l-2 border-brand-cream pl-6 space-y-6">
        @foreach([
          ['1) Chagua Plan', 'Tazama bei na vipengele, kisha nenda Checkout.'],
          ['2) Lipa kwa ZenoPay', 'Tunapokea mobile money & local rails.'],
          ['3) Auto-Provision', 'Akaunti yako ya Webuzo/cPanel inaundwa mara moja.'],
          ['4) Go Live', 'Bonyeza “Go to cPanel”, weka WordPress au app unayotaka, done.'],
        ] as $i => $item)
          <li data-aos="fade-right" data-aos-delay="{{ $i * 150 }}">
            <h4 class="font-semibold text-brand-ocean">{{ $item[0] }}</h4>
            <p class="text-brand-slate text-sm mt-1">{{ $item[1] }}</p>
          </li>
        @endforeach
      </ol>
    </div>
  </div>
</section>

{{-- ===================== ABOUT + SSO ===================== --}}
<section class="mt-16 grid lg:grid-cols-2 gap-8">
  <div class="card p-6 rounded-2xl" data-aos="fade-right">
    <h2 class="heading mb-4">About Hollyn</h2>
    <p class="text-brand-slate mb-4">
      Hollyn ni jukwaa la web hosting lililojengwa kwa ajili ya biashara zinazoanza na zinazokua.
      Tunaleta muunganiko mwepesi wa malipo ya ndani (TZ), auto-provision ya Webuzo, na usalama wa daraja la juu.
    </p>
    <ul class="space-y-2 text-sm text-brand-slate">
      <li class="flex items-start gap-2"><span class="text-brand-emerald mt-0.5">✓</span> Data-centers with SSD/NVMe</li>
      <li class="flex items-start gap-2"><span class="text-brand-emerald mt-0.5">✓</span> Free basic SSL kwa kila domain</li>
      <li class="flex items-start gap-2"><span class="text-brand-emerald mt-0.5">✓</span> Caching layers na PHP 8.x ready</li>
    </ul>
  </div>

  <div class="card p-6 rounded-2xl" data-aos="fade-left">
    <h2 class="heading mb-4">Webuzo & cPanel Access</h2>
    <p class="text-brand-slate mb-4">
      Baada ya malipo, mfumo wetu hutengeneza akaunti na kukupa <b>Go to cPanel</b>.
      Kwa baadhi ya mipango tunawasha <b>SSO</b> (single sign-on) ili uingie bila kuweka username/password mara kwa mara.
    </p>
    <div class="flex flex-wrap gap-3">
      <a href="{{ route('plans') }}" class="btn-primary px-5 py-2.5">Pick a Plan</a>
      @guest
        <a href="{{ route('register') }}" class="btn-gold px-5 py-2.5">Create Account</a>
      @endguest
    </div>
  </div>
</section>

{{-- ===================== TESTIMONIALS ===================== --}}
<section class="mt-16">
  <div class="text-center mb-8">
    <h2 class="heading" data-aos="fade-up">What Customers Say</h2>
  </div>
  <div class="card overflow-hidden rounded-2xl p-6">
    <div class="flex gap-6 animate-testimonial w-[200%]">
      @php
        $t = [
          ['“Checkout mpaka cPanel dakika chache tu.”','Asha, SME Owner'],
          ['“WordPress performance iko juu, na support hujibu haraka.”','Kelvin, Developer'],
          ['“Malipo ya ZenoPay ni rahisi sana kwa timu yetu ya fedha.”','Neema, NGO'],
        ];
      @endphp
      <div class="grid md:grid-cols-3 gap-5 min-w-full">
        @foreach($t as $x)
          <div class="bg-brand-cream/10 p-5 rounded-xl border border-brand-cream/20">
            <p class="text-brand-ocean font-semibold italic">{{ $x[0] }}</p>
            <p class="text-brand-slate text-sm mt-3">— {{ $x[1] }}</p>
          </div>
        @endforeach
      </div>
      <div class="grid md:grid-cols-3 gap-5 min-w-full">
        @foreach($t as $x)
          <div class="bg-brand-cream/10 p-5 rounded-xl border border-brand-cream/20">
            <p class="text-brand-ocean font-semibold italic">{{ $x[0] }}</p>
            <p class="text-brand-slate text-sm mt-3">— {{ $x[1] }}</p>
          </div>
        @endforeach
      </div>
    </div>
  </div>
</section>

{{-- ===================== FAQ ===================== --}}
<section class="mt-16">
  <div class="text-center mb-8">
    <h2 class="heading" data-aos="fade-up">FAQ</h2>
  </div>
  <div class="grid md:grid-cols-2 gap-6">
    @php
      $faq = [
        ['Nikipata tatizo, msaada upo saa ngapi?','Support ipo 24/7 kwa barua pepe/Chat (kulingana na plan).'],
        ['Domain inapatikana?','Unaweza kutumia domain uliyonayo au kuongeza mpya baadaye.'],
        ['Backups zinahifadhiwa muda gani?','Tunabeba rolling backups; retention inategemea plan yako.'],
        ['Naweza kubadilisha plan?','Ndiyo, unaweza kupandisha/chusha kiwango bila downtime.'],
      ];
    @endphp
    @foreach($faq as $i => $q)
      <details class="card p-5 rounded-2xl group" data-aos="fade-up" data-aos-delay="{{ $i * 100 }}">
        <summary class="cursor-pointer font-semibold text-brand-ocean list-none flex justify-between items-center">
          {{ $q[0] }}
          <svg class="w-5 h-5 transition-transform group-open:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
          </svg>
        </summary>
        <p class="text-brand-slate text-sm mt-3">{{ $q[1] }}</p>
      </details>
    @endforeach
  </div>
</section>

{{-- ===================== FINAL CTA ===================== --}}
<section class="mt-16 rounded-3xl bg-gradient-to-br from-white via-brand-cream/30 to-white p-8 md:p-10 border border-brand-cream/30 backdrop-blur-sm" data-aos="fade-up">
  <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-6 text-center md:text-left">
    <div>
      <h3 class="text-2xl md:text-3xl font-extrabold text-brand-ocean">Ready to go live?</h3>
      <p class="text-brand-slate mt-2">Chagua plan yako. Pokea cPanel link mara moja.</p>
    </div>
    <div class="flex flex-wrap justify-center gap-3">
      <a href="{{ route('plans') }}" class="btn-primary px-6 py-3">View Plans</a>
      @guest
        <a href="{{ route('register') }}" class="btn-gold px-6 py-3">Create Account</a>
      @endguest
    </div>
  </div>
</section>

<script src="https://unpkg.com/aos@2.3.4/dist/aos.js" async></script>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      AOS.init({ once: true, duration: 650, easing: 'ease-out-quart', offset: 80 });
    }

    // Counters
    const counterObserver = new IntersectionObserver((entries) => {
      entries.forEach(({ target, isIntersecting }) => {
        if (!isIntersecting || target.__done) return;
        target.__done = true;
        const val = parseFloat(target.getAttribute('data-val')) || 0;
        let cur = 0;
        const steps = Math.min(30, Math.max(10, val));
        const inc = val / steps;
        const timer = setInterval(() => {
          cur += inc;
          target.textContent = val % 1 ? cur.toFixed(1) : Math.round(cur);
          if (cur >= val) {
            target.textContent = val % 1 ? val.toFixed(1) : Math.round(val);
            clearInterval(timer);
          }
        }, 25);
      });
    }, { threshold: 0.5 });
    document.querySelectorAll('[data-counter]').forEach(el => counterObserver.observe(el));

    // Tabs
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    tabButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.tab;
        tabPanes.forEach(pane => pane.classList.toggle('hidden', pane.id !== target));
        tabButtons.forEach(b => b.classList.remove('btn-primary'));
        btn.classList.add('btn-primary');
      });
    });
    if (tabButtons[0]) tabButtons[0].click();
  });
</script>
@endsection