@extends('layouts.app')
@section('content')
<div class="max-w-md mx-auto">
  <div class="card">
    <h1 class="heading mb-4">Login</h1>
    <form method="POST" action="{{ route('login') }}" class="space-y-4">
      @csrf
      <div>
        <label class="block text-sm mb-1">Email</label>
        <input type="email" name="email" required class="w-full rounded-xl border-brand-cream focus:border-brand-emerald focus:ring-brand-emerald">
      </div>
      <div>
        <label class="block text-sm mb-1">Password</label>
        <input type="password" name="password" required class="w-full rounded-xl border-brand-cream focus:border-brand-emerald focus:ring-brand-emerald">
      </div>
      <div class="flex items-center justify-between">
        <label class="flex items-center gap-2 text-sm">
          <input type="checkbox" name="remember" class="rounded border-brand-cream text-brand-emerald">
          Remember me
        </label>
        <a href="{{ route('password.request') }}" class="text-sm">Forgot?</a>
      </div>
      <button class="btn-primary w-full">Sign in</button>
    </form>
  </div>
  <p class="text-center mt-4 text-sm">No account?
    <a href="{{ route('register') }}" class="font-semibold">Create one</a>
  </p>
</div>
@endsection
