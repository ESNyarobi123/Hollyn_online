<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto">
  <div class="card">
    <h1 class="heading mb-4">Login</h1>
    <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-4">
      <?php echo csrf_field(); ?>
      <div>
        <label class="block text-sm mb-1">Email</label>
        <input type="email" name="email" required class="w-full rounded-xl border-brand-cream focus:border-brand-emerald focus:ring-brand-emerald">
      </div>
      <div>
        <label class="block text-sm mb-1">Password</label>
        <input type="password" name="password" required class="w-full rounded-xl border-brand-cream focus:border-brand-emerald focus:ring-brand-emerald">
      </div>
      <div class="flex items-center justify-between">
        <label class="flex items-center gap-2 text-sm">
          <input type="checkbox" name="remember" class="rounded border-brand-cream text-brand-emerald">
          Remember me
        </label>
        <a href="<?php echo e(route('password.request')); ?>" class="text-sm">Forgot?</a>
      </div>
      <button class="btn-primary w-full">Sign in</button>
    </form>
  </div>
  <p class="text-center mt-4 text-sm">No account?
    <a href="<?php echo e(route('register')); ?>" class="font-semibold">Create one</a>
  </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/auth/login.blade.php ENDPATH**/ ?>