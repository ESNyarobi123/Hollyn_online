<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto">
  <div class="card">
    <h1 class="heading mb-4">Create account</h1>
    <form method="POST" action="<?php echo e(route('register')); ?>" class="space-y-4">
      <?php echo csrf_field(); ?>
      <div>
        <label class="block text-sm mb-1">Name</label>
        <input name="name" required class="w-full rounded-xl border-brand-cream focus:border-brand-emerald focus:ring-brand-emerald">
      </div>
      <div>
        <label class="block text-sm mb-1">Email</label>
        <input type="email" name="email" required class="w-full rounded-xl border-brand-cream focus:border-brand-emerald focus:ring-brand-emerald">
      </div>
      <div>
        <label class="block text-sm mb-1">Phone (optional)</label>
        <input name="phone" class="w-full rounded-xl border-brand-cream focus:border-brand-emerald focus:ring-brand-emerald">
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm mb-1">Password</label>
          <input type="password" name="password" required class="w-full rounded-xl border-brand-cream focus:border-brand-emerald focus:ring-brand-emerald">
        </div>
        <div>
          <label class="block text-sm mb-1">Confirm</label>
          <input type="password" name="password_confirmation" required class="w-full rounded-xl border-brand-cream focus:border-brand-emerald focus:ring-brand-emerald">
        </div>
      </div>
      <button class="btn-gold w-full">Create account</button>
    </form>
  </div>
  <p class="text-center mt-4 text-sm">Already have an account?
    <a href="<?php echo e(route('login')); ?>" class="font-semibold">Sign in</a>
  </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/auth/register.blade.php ENDPATH**/ ?>