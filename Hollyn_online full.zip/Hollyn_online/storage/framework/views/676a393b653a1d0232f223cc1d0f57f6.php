
<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  
  <style>
    :root{
      --brand-ocean:#0f172a;   /* deep slate/ocean */
      --brand-cream:#f1f5f9;   /* light slate/cream */
      --brand-gold:#f59e0b;    /* amber/gold */
      --brand-emerald:#059669; /* emerald */
      --brand-slate:#475569;   /* slate text */
      --brand-ink:#0b1220;
      --ring:rgba(15,23,42,.12);
      --line:#e5e7eb;
      --indigo:#4f46e5; --violet:#7c3aed; --rose:#e11d48; --cyan:#0891b2;
    }
    .d-none{display:none}
    .text-brand-ocean{color:var(--brand-ocean)}
    .text-brand-slate{color:var(--brand-slate)}
    .text-brand-emerald{color:var(--brand-emerald)}
    .bg-brand-cream{background-color:var(--brand-cream)}
    .border-brand-cream{border-color:var(--brand-cream)}
    .btn{display:inline-flex;align-items:center;gap:.5rem;padding:.55rem 1rem;border-radius:1rem;border:1px solid transparent;font-weight:600;transition:.15s;cursor:pointer}
    .btn:focus{outline:none;box-shadow:0 0 0 4px var(--ring)}
    .btn-primary{background:var(--brand-ocean);color:#fff}
    .btn-primary:hover{transform:translateY(-1px)}
    .btn-gold{background:var(--brand-gold);color:#111827}
    .btn-gold:hover{filter:brightness(1.03)}
    .btn-ghost{border-color:var(--brand-cream);color:var(--brand-ocean);background:#fff}
    .btn-ghost:hover{background:var(--brand-cream)}
    .card{background:#fff;border:1px solid var(--brand-cream);border-radius:1.25rem;padding:1rem;box-shadow:0 1px 0 rgba(2,6,23,.04)}
    .kpi{display:flex;gap:.9rem;align-items:flex-start;border-radius:1rem;padding:1rem;color:#fff}
    .kpi .icon{display:grid;place-items:center;min-width:40px;height:40px;border-radius:.9rem;background:rgba(255,255,255,.15)}
    .k1{background:linear-gradient(135deg,var(--brand-emerald),#22c55e)}
    .k2{background:linear-gradient(135deg,var(--indigo),#3b82f6)}
    .k3{background:linear-gradient(135deg,var(--brand-gold),#f97316);color:#111827}
    .k4{background:linear-gradient(135deg,var(--violet),#8b5cf6)}
    .table-wrap{border:1px solid var(--brand-cream);border-radius:1rem;overflow:hidden;background:#fff}
    table.table{width:100%;border-collapse:collapse}
    .table thead th{font-weight:700;color:#334155;background:#f8fafc}
    .table td,.table th{padding:.75rem 1rem;border-top:1px solid var(--brand-cream);font-size:.92rem;vertical-align:middle}
    .pill{display:inline-flex;align-items:center;padding:.15rem .5rem;border-radius:999px;font-size:.75rem;font-weight:800}
    .pill-emerald{background:#ecfdf5;color:#065f46}
    .pill-amber{background:#fff7ed;color:#92400e}
    .pill-gray{background:#e5e7eb;color:#374151}
    .alert{border-radius:.9rem;padding:.75rem 1rem;font-weight:600}
    .alert-success{background:#ecfdf5;color:#065f46;border:1px solid #d1fae5}
    .alert-danger{background:#fef2f2;color:#991b1b;border:1px solid #fee2e2}
    .alert-info{background:#eff6ff;color:#1e40af;border:1px solid #dbeafe}
    .muted{color:#6b7280}
  </style>

  <?php
    use Illuminate\Support\Facades\Schema;

    // ---------- Helpers ----------
    $s = $stats ?? [];
    $services = collect($services ?? []);
    $orders = collect($recentOrders ?? []);
    $cta = $cta ?? ['show_finish_setup'=>false,'show_upgrade'=>false,'panel_url'=>null];

    $fmt = fn($n)=> is_numeric($n) ? number_format((float)$n) : (is_string($n) ? $n : '0');
    $abbr = function($n){
      $n = (float)($n ?? 0);
      if ($n >= 1_000_000_000) return round($n/1_000_000_000,2).'B';
      if ($n >= 1_000_000)     return round($n/1_000_000,2).'M';
      if ($n >= 1_000)         return round($n/1_000,1).'K';
      return number_format($n);
    };
    $safeRoute = function(string $name, array $params = []) {
      try { return \Illuminate\Support\Facades\Route::has($name) ? route($name, $params) : null; }
      catch (\Throwable $e) { return null; }
    };

    // ========= REAL COUNTS from DB (fallback to $stats) =========
    try {
      // Active services
      $activeCount = \App\Models\Service::query()
        ->when(Schema::hasColumn('services','status'), fn($q)=>$q->whereRaw('LOWER(status) = "active"'))
        ->count();
      // Provisioning services
      $provCount = \App\Models\Service::query()
        ->when(Schema::hasColumn('services','status'), fn($q)=>$q->whereRaw('LOWER(status) = "provisioning"'))
        ->count();

      // Orders
      $orderPaidStatuses = ['paid','active','complete','completed','succeeded','success'];
      $ordersTotalReal = \App\Models\Order::query()->count();
      $ordersPaidReal  = \App\Models\Order::query()
        ->when(Schema::hasColumn('orders','status'), fn($q)=>$q->whereIn(\DB::raw('LOWER(status)'), $orderPaidStatuses))
        ->count();

      // Revenue (TZS)
      $revenueTzsReal = \App\Models\Order::query()
        ->when(Schema::hasColumn('orders','status'), fn($q)=>$q->whereIn(\DB::raw('LOWER(status)'), $orderPaidStatuses))
        ->sum('price_tzs');

      // Last payment at
      $lastPaymentAtReal = optional(
        \App\Models\Order::query()
          ->when(Schema::hasColumn('orders','status'), fn($q)=>$q->whereIn(\DB::raw('LOWER(status)'), $orderPaidStatuses))
          ->latest('updated_at')->first()
      )->updated_at;

      // Merge into $s preserving provided stats as fallback
      $s['services_active']        = $s['services_active']        ?? $activeCount;
      $s['services_provisioning']  = $s['services_provisioning']  ?? $provCount;
      $s['orders_total']           = $s['orders_total']           ?? $ordersTotalReal;
      $s['orders_paid']            = $s['orders_paid']            ?? $ordersPaidReal;
      $s['revenue_tzs']            = $s['revenue_tzs']            ?? $revenueTzsReal;
      $s['last_payment_at']        = $s['last_payment_at']        ?? $lastPaymentAtReal;
    } catch (\Throwable $__) {
      // silent: keep whatever was in $s
    }

    // Sparkline (fallback safe)
    $spark = is_array($revenueLast7 ?? null) ? $revenueLast7 : [12,18,15,21,19,26,30];
    $max = max($spark ?: [1]); $w = 180; $h = 42;
    $pts=[]; foreach($spark as $i=>$v){ $x = (count($spark)>1 ? $i/(count($spark)-1) : 0) * $w; $y = $h - ($max>0 ? ($v/$max)*$h : 0); $pts[]="$x,$y"; }
    $lastSpark = $spark[count($spark)-1] ?? 0;

    // Try to preload some services data if empty (for table)
    if ($services->isEmpty()) {
      try {
        $services = \App\Models\Service::with('plan')->latest('id')->limit(12)->get();
      } catch (\Throwable $__) {}
    }

    // Active service + panel link logic
    $hasActiveService = \App\Models\Service::query()->when(Schema::hasColumn('services','status'), fn($q)=>$q->whereRaw('LOWER(status)="active"'))->exists();
    $panelFromSvc = optional($services->first(fn($svc)=> !empty(data_get($svc,'enduser_url')) && strtolower((string) data_get($svc,'status','')) === 'active'));
    $panelHrefCandidate = data_get($panelFromSvc,'enduser_url');
    $panelHref = $cta['panel_url'] ?? $panelHrefCandidate ?? $safeRoute('me.panel');
    $showOpenPanelBtn = $hasActiveService && !empty($panelHref);

    // Common routes
    $servicesIndex = $safeRoute('admin.services.index');
    $ordersIndex   = $safeRoute('admin.orders.index');
    $provisionUrl  = $safeRoute('me.services.provisionLatest'); // optional
    $statusUrl     = $safeRoute('me.services.status');

    // Logout route (Laravel default POST /logout)
    $logoutUrl = $safeRoute('logout') ?? url('/logout');
  ?>

  
  <?php if(session('status')): ?>
    <div class="alert alert-success mb-4" id="statusBanner"><?php echo e(session('status')); ?></div>
  <?php else: ?>
    <div class="alert alert-info mb-4 d-none" id="statusBanner"></div>
  <?php endif; ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger mb-4">
      <?php echo e($errors->first()); ?>

    </div>
  <?php endif; ?>

  
  <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
    <div>
      <h1 class="text-3xl font-extrabold text-brand-ocean tracking-tight">Admin Dashboard</h1>
      <p class="text-brand-slate">Orders, services & revenue at a glance.</p>
    </div>

    <div class="flex flex-wrap gap-2">
      
      <?php if($showOpenPanelBtn): ?>
        <a href="<?php echo e($panelHref); ?>" class="btn btn-primary" title="Open a customer panel (last active)" target="_blank" rel="noopener">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M8 12h8M4 6h16M4 18h10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          Open Panel
        </a>
      <?php endif; ?>

      
      <?php if(!empty($cta['show_finish_setup']) && $provisionUrl): ?>
        <form method="POST" action="<?php echo e($provisionUrl); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-gold" id="finishBtn" title="Provision latest paid order">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#111827" stroke-width="2" stroke-linecap="round"/></svg>
            Finish setup
          </button>
        </form>
      <?php endif; ?>

      
      <form id="logoutForm" class="inline" action="<?php echo e($logoutUrl); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-ghost" title="Logout">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 3h4v18h-4M10 17l5-5-5-5M15 12H3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
          Logout
        </button>
      </form>
    </div>
  </div>

  
  <div class="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
    <div class="kpi k2 card" style="border:0">
      <div class="icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 3h18v4H3zM6 7v14m6-14v14m6-14v14" stroke="#fff" stroke-width="2"/></svg>
      </div>
      <div>
        <div class="text-xs" style="opacity:.9">Total Orders</div>
        <div class="text-3xl font-extrabold">~ <?php echo e($fmt($s['orders_total'] ?? 0)); ?></div>
        <div class="text-xs" style="opacity:.9">Paid/Active: <?php echo e($fmt($s['orders_paid'] ?? 0)); ?></div>
      </div>
    </div>

    <div class="kpi k1 card" style="border:0">
      <div class="icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M5 12l4 4L19 6" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </div>
      <div>
        <div class="text-xs" style="opacity:.9">Active Services</div>
        <div class="text-3xl font-extrabold"><?php echo e($fmt($s['services_active'] ?? 0)); ?></div>
        <div class="text-xs" style="opacity:.9">Provisioning: <?php echo e($fmt($s['services_provisioning'] ?? 0)); ?></div>
      </div>
    </div>

    <div class="kpi k3 card" style="border:0">
      <div class="icon" style="background:#1118271a;color:#111827">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 12h18M3 6h18M3 18h18" stroke="#111827" stroke-width="2" stroke-linecap="round"/></svg>
      </div>
      <div>
        <div class="text-xs">Revenue (TZS)</div>
        <div class="text-3xl font-extrabold">TZS <?php echo e($fmt($s['revenue_tzs'] ?? 0)); ?></div>
        <div class="text-xs">Last payment:
          <span style="opacity:.8"><?php echo e(!empty($s['last_payment_at']) ? \Illuminate\Support\Carbon::parse($s['last_payment_at'])->format('Y-m-d H:i') : '—'); ?></span>
        </div>
      </div>
    </div>

    <div class="kpi k4 card" style="border:0">
      <div class="icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 20V4m0 0L7 9m5-5 5 5" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>
      </div>
      <div>
        <div class="text-xs" style="opacity:.9">Last 7 days</div>
        <div class="flex items-end gap-3">
          <div class="text-2xl font-extrabold">TZS <?php echo e($abbr($lastSpark)); ?></div>
          <svg width="<?php echo e($w); ?>" height="<?php echo e($h); ?>" viewBox="0 0 <?php echo e($w); ?> <?php echo e($h); ?>" aria-hidden="true">
            <polyline fill="none" stroke="#fff" stroke-width="2" points="<?php echo e(implode(' ', $pts)); ?>"/>
          </svg>
        </div>
        <div class="text-xs" style="opacity:.9">Trend preview</div>
      </div>
    </div>
  </div>

  
  <div class="mt-6 card">
    <div class="flex items-center justify-between">
      <h3 class="text-lg font-semibold text-brand-ocean">Services</h3>
      <div class="flex gap-2">
        <?php if($servicesIndex): ?>
          <a href="<?php echo e($servicesIndex); ?>" class="btn btn-ghost">All Services</a>
        <?php endif; ?>
        <?php if(!empty($cta['show_finish_setup']) && $provisionUrl): ?>
          <form method="POST" action="<?php echo e($provisionUrl); ?>">
            <?php echo csrf_field(); ?>
            <button class="btn btn-gold" type="submit" id="finishBtn2">Finish setup</button>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <div class="mt-3 table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th class="text-left">Plan</th>
            <th class="text-left">Domain</th>
            <th class="text-left">Status</th>
            <th class="text-left">Panel</th>
            <th class="text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php if($services->isEmpty()): ?>
          <tr><td colspan="5" class="py-6 text-center text-brand-slate">No services yet.</td></tr>
        <?php else: ?>
          <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $planName = data_get($svc,'plan.name') ?? data_get($svc,'plan_name') ?? data_get($svc,'plan_title') ?? '—';
              $domain   = data_get($svc,'domain','—');
              $status   = strtolower((string) data_get($svc,'status','pending'));
              $isActive = $status === 'active';
              $pillCls  = $isActive ? 'pill pill-emerald' : ($status==='provisioning' ? 'pill pill-amber' : 'pill pill-gray');
              $panelUrl = data_get($svc,'enduser_url') ?: data_get($svc,'panel_url');
              $svcShow  = $servicesIndex ? route('admin.services.show', data_get($svc,'id')) : null;
            ?>
            <tr>
              <td><?php echo e($planName); ?></td>
              <td><?php echo e($domain); ?></td>
              <td><span class="<?php echo e($pillCls); ?>"><?php echo e(ucfirst($status)); ?></span></td>
              <td>
                <?php if($isActive && $panelUrl): ?>
                  <a class="text-brand-emerald underline" href="<?php echo e($panelUrl); ?>" target="_blank" rel="noopener">Open</a>
                <?php else: ?>
                  <span class="muted">—</span>
                <?php endif; ?>
              </td>
              <td class="text-right">
                <div class="flex gap-2 justify-end">
                  <?php if($svcShow): ?><a class="btn btn-ghost" href="<?php echo e($svcShow); ?>">Inspect</a><?php endif; ?>
                  <?php if(!$isActive && !empty($cta['show_finish_setup']) && $provisionUrl): ?>
                    <form method="POST" action="<?php echo e($provisionUrl); ?>" class="inline">
                      <?php echo csrf_field(); ?>
                      <button class="btn btn-ghost" type="submit">Provision</button>
                    </form>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <div class="mt-6 card">
    <div class="flex items-center justify-between">
      <h3 class="text-lg font-semibold text-brand-ocean">Recent Orders</h3>
      <?php if($ordersIndex): ?>
        <a href="<?php echo e($ordersIndex); ?>" class="text-sm text-brand-emerald hover:underline">View all</a>
      <?php endif; ?>
    </div>
    <div class="mt-3 table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th class="text-left">#</th>
            <th class="text-left">Plan</th>
            <th class="text-left">Amount</th>
            <th class="text-left">Status</th>
            <th class="text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if($orders->isEmpty()): ?>
            <tr><td colspan="5" class="py-6 text-center text-brand-slate">No recent orders.</td></tr>
          <?php else: ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $oid    = (int) (data_get($o,'id') ?? 0);
                $pname  = data_get($o,'plan.name') ?? data_get($o,'plan_name') ?? data_get($o,'plan_title') ?? '—';
                $amount = (float) (data_get($o,'price_tzs',0) ?? 0);
                $status = strtolower((string) data_get($o,'status','pending'));
                $badge  = in_array($status,['paid','active','complete','succeeded']) ? 'pill pill-emerald' : ($status === 'failed' ? 'pill pill-gray' : 'pill pill-amber');

                $orderSummary = $oid ? $safeRoute('order.summary',[$oid]) : null;
                $payStart     = ($status==='pending' && $oid) ? $safeRoute('pay.start',[$oid]) : null;
                $adminOrder   = $ordersIndex ? route('admin.orders.show', $oid) : null;
              ?>
              <tr>
                <td>#<?php echo e($oid ?: '—'); ?></td>
                <td><?php echo e($pname); ?></td>
                <td>TZS <?php echo e(number_format($amount)); ?></td>
                <td><span class="<?php echo e($badge); ?>"><?php echo e(ucfirst($status)); ?></span></td>
                <td class="text-right">
                  <div class="flex gap-2 justify-end">
                    <?php if($adminOrder): ?><a class="btn btn-ghost" href="<?php echo e($adminOrder); ?>">Inspect</a><?php endif; ?>
                    <?php if($orderSummary): ?><a class="btn btn-ghost" href="<?php echo e($orderSummary); ?>">View</a><?php endif; ?>
                    <?php if($payStart): ?><a class="btn btn-primary" href="<?php echo e($payStart); ?>">Pay now</a><?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <script>
    (function(){
      const bannerEl = document.getElementById('statusBanner');
      const statusUrl = <?php echo json_encode($statusUrl, 15, 512) ?>;
      if (!statusUrl) return;

      async function pollStatus() {
        try {
          const res = await fetch(statusUrl, { headers: { 'Accept': 'application/json' } });
          if (!res.ok) return;
          const s = await res.json(); // {active, provisioning, requested, failed}
          if (!bannerEl) return;

          bannerEl.classList.remove('d-none');

          if ((s.active ?? 0) > 0) {
            bannerEl.className = 'alert alert-success mb-4';
            bannerEl.textContent = 'Service is Active. Karibu kwenye paneli ya mteja.';
          } else if ((s.failed ?? 0) > 0) {
            bannerEl.className = 'alert alert-danger mb-4';
            bannerEl.textContent = 'Provisioning failed. Tafadhali jaribu tena au wasiliana na msaada.';
          } else if ((s.provisioning ?? 0) > 0 || (s.requested ?? 0) > 0) {
            bannerEl.className = 'alert alert-info mb-4';
            bannerEl.textContent = 'Provisioning… Subiri kidogo hadi hali ifike Active.';
          } else {
            bannerEl.className = 'alert alert-info mb-4';
            bannerEl.textContent = 'Status updated.';
          }
        } catch(e) { /* silent */ }
      }

      const hasFinish = document.getElementById('finishBtn') || document.getElementById('finishBtn2');
      if (bannerEl || hasFinish) {
        setInterval(pollStatus, 5000);
      }
    })();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>