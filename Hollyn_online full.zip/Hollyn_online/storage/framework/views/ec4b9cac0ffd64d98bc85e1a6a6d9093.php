

<?php $__env->startSection('content'); ?>
  
  <style>
    .card{background:#fff;border:1px solid #e5e7eb;border-radius:1rem;padding:1rem;box-shadow:0 1px 0 rgba(2,6,23,.04)}
    .badge{display:inline-grid;place-items:center;min-width:20px;height:20px;border-radius:999px;background:#ecfdf5;color:#065f46;font-size:.75rem;font-weight:800}
    .chip{display:inline-flex;align-items:center;gap:.4rem;padding:.22rem .6rem;border-radius:999px;font-size:.78rem;font-weight:700;border:1px solid #e5e7eb;background:#f8fafc;color:#0f172a}
    .ribbon{position:absolute;left:12px;top:-10px}
    .ribbon span{display:inline-block;padding:.15rem .6rem;border-radius:999px;background:#f59e0b;color:#111827;font-weight:800;font-size:.72rem;box-shadow:0 6px 22px rgba(2,6,23,.08)}
    dialog[open]{animation:pop .18s ease-out}
    @keyframes pop{from{transform:scale(.98);opacity:.0} to{transform:scale(1);opacity:1}}
  </style>

  
  <div class="flex items-center justify-between mb-6">
    <div>
      <h2 class="heading">Hosting Plans</h2>
      <p class="text-brand-slate mt-1">Chagua mpango unaokufaa — lipa kwa ZenoPay, provision automatic, kisha nenda cPanel mara moja.</p>
    </div>
    <a href="<?php echo e(route('home')); ?>" class="hidden sm:inline-flex btn-gold">Back to Home</a>
  </div>

  <?php
    use Illuminate\Support\Str;

    /**
     * Parse features from various formats to a normalized collection of pairs:
     *  - returns: collect([['k'=>'Disk Space','v'=>'20 GB'], ...])
     */
    // Store closure globally for recursive use
    $GLOBALS['__parseFeaturePairs'] = null;
    $parseFeaturePairs = $GLOBALS['__parseFeaturePairs'] = function($raw){
      // 1) If it's already array AND associative → map to pairs
      if (is_array($raw)) {
        $isAssoc = array_keys($raw)!==range(0, count($raw)-1);
        if ($isAssoc) {
          return collect($raw)->map(function($v,$k){
            return ['k'=>(string)$k, 'v'=>(string)$v];
          })->values();
        }
        // Non-assoc list → each line becomes single value; try split "Key: Value" if possible
        return collect($raw)->filter()->map(function($line){
          $line = trim((string)$line);
          if ($line==='') return null;
          if (Str::contains($line, ':')) {
            [$k,$v] = array_map('trim', explode(':',$line,2));
            return ['k'=>$k ?: 'Feature', 'v'=>$v ?: 'Yes'];
          }
          return ['k'=>'Feature', 'v'=>$line];
        })->filter()->values();
      }

      // 2) If it's JSON string
      if (is_string($raw) && Str::startsWith(trim($raw), ['{','['])) {
        try {
          $arr = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
          // Use $this closure reference instead of undefined variable
          return ($GLOBALS['__parseFeaturePairs'] ?? null)
            ? ($GLOBALS['__parseFeaturePairs'])($arr)
            : null;
        } catch (\Throwable $__) { /* fallthrough to lines */ }
      }

      // 3) If it's plain multiline text → split lines
      $text = trim((string)$raw);
      if ($text==='') return collect();

      $lines = preg_split('/\r\n|\r|\n/', $text);
      return collect($lines)->map(function($line){
        $line = trim($line);
        if ($line==='') return null;
        if (Str::contains($line, ':')) {
          [$k,$v] = array_map('trim', explode(':',$line,2));
          return ['k'=>$k ?: 'Feature', 'v'=>$v ?: 'Yes'];
        }
        return ['k'=>'Feature', 'v'=>$line];
      })->filter()->values();
    };

    /**
     * Helper to read specific feature value by name (case-insensitive).
     */
    $getFeatureValue = function($plan, string $name) use ($parseFeaturePairs){
      $pairs = $parseFeaturePairs($plan->features ?? []);
      $needle = Str::lower($name);
      $found = $pairs->first(fn($p)=> Str::lower((string)$p['k']) === $needle);
      return $found['v'] ?? null;
    };
  ?>

  
  <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $isPopular = $p->slug === 'hollyn-boost';
        $isMax     = $p->slug === 'hollyn-max';

        $pairs     = $parseFeaturePairs($p->features ?? []);
        $preview   = $pairs->take(4);

        $perLabel  = ($p->period_months ?? 1) > 1 ? '/ '.((int)$p->period_months).' months' : 'per month';
      ?>

      <div class="relative group">
        
        <?php if($isPopular): ?>
          <div class="ribbon"><span>Most Popular</span></div>
        <?php endif; ?>

        <div class="card h-full transition-transform duration-200 group-hover:-translate-y-1">
          
          <div class="flex items-center justify-between">
            <div>
              <div class="text-sm text-brand-slate"><?php echo e($p->slug); ?></div>
              <h3 class="text-xl font-semibold text-brand-ocean"><?php echo e($p->name); ?></h3>
            </div>
            <div class="rounded-xl px-2 py-1 text-xs font-medium <?php echo e($p->is_active ? 'bg-brand-cream text-brand-ocean' : 'bg-gray-200 text-gray-600'); ?>">
              <?php echo e($p->is_active ? 'Active' : 'Inactive'); ?>

            </div>
          </div>

          
          <div class="mt-3">
            <div class="text-3xl font-extrabold text-brand-emerald">TZS <?php echo e(number_format((int)$p->price_tzs)); ?></div>
            <div class="text-xs text-brand-slate"><?php echo e($perLabel); ?></div>
          </div>

          
          <?php if($preview->isNotEmpty()): ?>
            <div class="mt-4 flex flex-wrap gap-2">
              <?php $__currentLoopData = $preview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $label = trim((string)($it['k'] ?? 'Feature'));
                  $value = trim((string)($it['v'] ?? 'Yes'));
                  $display = $isMax && Str::lower($value) === 'unlimited' ? '∞ Unlimited' : $value;
                ?>
                <span class="chip">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 12l4 4L19 6" stroke="#059669" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                  <strong><?php echo e($label); ?>:</strong>&nbsp;<?php echo e($display); ?>

                </span>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php else: ?>
            <ul class="mt-4 space-y-2">
              <li class="flex items-start gap-2">
                <span class="badge shrink-0 mt-0.5">✓</span>
                <span class="text-sm text-brand-slate">Optimized PHP • SSD • Free SSL</span>
              </li>
            </ul>
          <?php endif; ?>

          
          <div class="mt-5 flex items-center gap-3">
            <a class="btn-primary flex-1 justify-center" href="<?php echo e(route('checkout.show', $p)); ?>">
              Order <?php echo e($p->name); ?>

            </a>
            <button type="button"
                    onclick="document.getElementById('feat-<?php echo e($p->id); ?>')?.showModal()"
                    class="px-3 py-2 rounded-xl border border-brand-cream text-sm text-brand-ocean hover:bg-brand-cream/60">
              View all
            </button>
          </div>
        </div>
      </div>

      
      <dialog id="feat-<?php echo e($p->id); ?>" class="rounded-2xl shadow-soft backdrop:bg-black/40 w-11/12 max-w-2xl">
        <form method="dialog" class="p-0 m-0">
          <div class="p-5 border-b border-brand-cream/60 flex items-center justify-between">
            <div>
              <div class="text-sm text-brand-slate"><?php echo e($p->slug); ?></div>
              <div class="text-lg font-semibold text-brand-ocean">
                <?php echo e($p->name); ?> — <span class="text-brand-emerald">TZS <?php echo e(number_format((int)$p->price_tzs)); ?></span>
                <span class="text-xs text-brand-slate ml-1"><?php echo e($perLabel); ?></span>
              </div>
            </div>
            <button class="px-3 py-1.5 rounded-lg bg-brand-ocean text-white">Close</button>
          </div>
        </form>
        <div class="p-5">
          <?php $all = $pairs; ?>
          <?php if($all->isEmpty()): ?>
            <p class="text-brand-slate text-sm">No features provided for this plan.</p>
          <?php else: ?>
            <div class="grid sm:grid-cols-2 gap-4">
              <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $label = trim((string)($it['k'] ?? 'Feature'));
                  $value = trim((string)($it['v'] ?? 'Yes'));
                  $display = ($p->slug === 'hollyn-max' && Str::lower($value) === 'unlimited') ? '∞ Unlimited' : $value;
                ?>
                <div class="p-3 rounded-xl bg-brand-cream/60">
                  <div class="text-xs text-brand-slate"><?php echo e($label); ?></div>
                  <div class="text-brand-ocean font-semibold"><?php echo e($display); ?></div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
          <div class="mt-5">
            <a class="btn-gold" href="<?php echo e(route('checkout.show', $p)); ?>">Continue with <?php echo e($p->name); ?></a>
          </div>
        </div>
      </dialog>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  
  <div class="mt-10 card">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
      <div>
        <div class="text-lg font-semibold text-brand-ocean">Compare features across all plans</div>
        <p class="text-brand-slate text-sm">Angalia tofauti zote kwa macho: disk, bandwidth, emails, DBs, domains na mengine.</p>
      </div>
      <a href="<?php echo e(route('plans')); ?>#compare" class="btn-primary">Open Comparison</a>
    </div>
  </div>

  
  <div id="compare" class="mt-8">
    <?php
      // Order ya features utakaionyesha mstari kwa mstari
      $featureOrder = [
        'Disk Space Quota',
        'Max Inodes',
        'Monthly Bandwidth',
        'Max FTP Accounts',
        'Max Email Accounts',
        'Max Quota per Mailbox',
        'Max MySQL Databases',
        'Max Subdomains',
        'Max Parked (Aliases)',
        'Max Addon Domains',
        'Hourly Email Limit (domain)',
        'Max % Failed/Deferred / hr',
      ];

      $bySlug = $plans->keyBy('slug');
      $cols   = ['hollyn-lite','hollyn-grow','hollyn-boost','hollyn-max'];

      $val = function($slug, $feat) use ($bySlug, $getFeatureValue){
        $pl = $bySlug->get($slug);
        if (!$pl) return '—';
        $v = $getFeatureValue($pl, $feat) ?? '—';
        if ($slug === 'hollyn-max' && \Illuminate\Support\Str::lower((string)$v) === 'unlimited') return '∞ Unlimited';
        return $v;
      };
    ?>

    <div class="card overflow-x-auto">
      <h3 class="heading mb-4">Full Comparison</h3>
      <table class="min-w-full text-sm">
        <thead>
          <tr class="text-left">
            <th class="py-3 pr-6 text-brand-ocean">Feature</th>
            <?php $__currentLoopData = $cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $pl = $bySlug->get($slug); ?>
              <th class="py-3 px-4">
                <?php if($pl): ?>
                  <div class="font-semibold text-brand-ocean"><?php echo e($pl->name); ?></div>
                  <div class="text-brand-emerald font-bold">
                    TZS <?php echo e(number_format((int)$pl->price_tzs)); ?>

                    <span class="text-xs text-brand-slate">
                      <?php echo e((($pl->period_months ?? 1) > 1) ? '/ '.((int)$pl->period_months).' mo' : 'per month'); ?>

                    </span>
                  </div>
                <?php else: ?>
                  <div class="text-brand-slate">—</div>
                <?php endif; ?>
              </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $featureOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t">
              <td class="py-2 pr-6 text-brand-ocean"><?php echo e($feat); ?></td>
              <?php $__currentLoopData = $cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $v = $val($slug, $feat); ?>
                <td class="py-2 px-4 <?php echo e(($slug==='hollyn-max' && \Illuminate\Support\Str::startsWith($v,'∞')) ? 'text-brand-emerald font-semibold' : 'text-brand-slate'); ?>">
                  <?php echo e($v); ?>

                </td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/public/plans.blade.php ENDPATH**/ ?>