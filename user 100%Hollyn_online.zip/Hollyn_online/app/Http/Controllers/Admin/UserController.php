<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;

class UserController extends Controller
{
    public function index()
    {
        $users = User::latest('id')->paginate(20);
        return view('admin.users.index', compact('users'));
    }

    public function show(User $user)
    {
        $user->loadCount(['orders','services']);
        return view('admin.users.show', compact('user'));
    }

    public function destroy(User $user)
    {
        // Onyo: hakikisha cascading au checks zako zipo kabla ya kufuta
        $user->delete();
        return back()->with('ok','User deleted.');
    }
}
