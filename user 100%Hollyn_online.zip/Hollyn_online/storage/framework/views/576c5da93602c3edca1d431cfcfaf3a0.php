<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_','-',app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e($title ?? config('app.name')); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="min-h-screen">
  <header class="topbar">
    <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
      <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-2">
        <span class="rounded-xl w-8 h-8 bg-brand-gold inline-block"></span>
        <span class="font-bold text-brand-ocean"><?php echo e(config('app.name','Hollyn Hosting')); ?></span>
      </a>
      <nav class="flex items-center gap-4">
        <a href="<?php echo e(route('plans')); ?>" class="hover:underline">Plans</a>
        <?php if(auth()->guard()->check()): ?>
          <a href="<?php echo e(route('dashboard')); ?>" class="hover:underline">Dashboard</a>
          <?php if(auth()->user()->role === 'admin'): ?>
            <a href="<?php echo e(route('admin.index')); ?>" class="hover:underline">Admin</a>
          <?php endif; ?>
          <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn-gold">Logout</button>
          </form>
        <?php else: ?>
          <a href="<?php echo e(route('login')); ?>" class="btn-primary">Login</a>
          <a href="<?php echo e(route('register')); ?>" class="btn-gold">Register</a>
        <?php endif; ?>
      </nav>
    </div>
  </header>

  <main class="max-w-7xl mx-auto px-4 py-6">
    <?php echo e($slot ?? ''); ?>

    <?php echo $__env->yieldContent('content'); ?>
  </main>

  <footer class="mt-10 border-t border-brand-cream/70">
    <div class="max-w-7xl mx-auto px-4 py-6 text-sm text-brand-slate">
      © <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.
    </div>
  </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/layouts/app.blade.php ENDPATH**/ ?>