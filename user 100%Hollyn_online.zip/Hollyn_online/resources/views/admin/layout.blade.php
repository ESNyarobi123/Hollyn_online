<!DOCTYPE html>
<html lang="en" x-data="{ open:false }">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title','Admin')</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,'Helvetica Neue',Arial}
    [x-cloak]{ display:none !important; }
  </style>
</head>
<body class="bg-slate-50 pt-14 md:pt-0">
  @php
    // Salama dhidi ya RouteNotFoundException
    $adminIndex    = \Illuminate\Support\Facades\Route::has('admin.index')          ? route('admin.index')          : url('/admin');
    $servicesIndex = \Illuminate\Support\Facades\Route::has('admin.services.index') ? route('admin.services.index') : '#';
    $ordersIndex   = \Illuminate\Support\Facades\Route::has('admin.orders.index')   ? route('admin.orders.index')   : '#';
    $usersIndex    = \Illuminate\Support\Facades\Route::has('admin.users.index')    ? route('admin.users.index')    : '#';
    $plansIndex    = \Illuminate\Support\Facades\Route::has('admin.plans.index')    ? route('admin.plans.index')    : '#';
  @endphp

  <div class="min-h-screen flex">
    <!-- Sidebar -->
    <aside class="w-64 bg-white border-r hidden md:block fixed md:static inset-y-0">
      <div class="p-4 text-xl font-bold">Admin Panel</div>
      <nav class="px-2 space-y-1">
        <a href="{{ $adminIndex }}" class="block px-3 py-2 rounded hover:bg-slate-100 {{ request()->routeIs('admin.index') ? 'bg-slate-100 font-semibold' : '' }}">Dashboard</a>
        <a href="{{ $servicesIndex }}" class="block px-3 py-2 rounded hover:bg-slate-100 {{ request()->is('admin/services*') ? 'bg-slate-100 font-semibold' : '' }}">Services</a>
        <a href="{{ $ordersIndex }}" class="block px-3 py-2 rounded hover:bg-slate-100 {{ request()->is('admin/orders*') ? 'bg-slate-100 font-semibold' : '' }}">Orders</a>
        <a href="{{ $usersIndex }}" class="block px-3 py-2 rounded hover:bg-slate-100 {{ request()->is('admin/users*') ? 'bg-slate-100 font-semibold' : '' }}">Users</a>
        <a href="{{ $plansIndex }}" class="block px-3 py-2 rounded hover:bg-slate-100 {{ request()->is('admin/plans*') ? 'bg-slate-100 font-semibold' : '' }}">Plans</a>
      </nav>
    </aside>

    <!-- Mobile topbar -->
    <div class="md:hidden fixed top-0 inset-x-0 bg-white border-b z-50" x-cloak>
      <div class="h-14 flex items-center justify-between px-3">
        <button @click="open=!open" class="p-2 rounded hover:bg-slate-100" aria-label="Toggle menu">
          ☰
        </button>
        <div class="font-semibold">Admin</div>
        <div></div>
      </div>
      <div x-show="open" x-transition class="bg-white border-t">
        <a href="{{ $adminIndex }}" class="block px-4 py-3 border-b">Dashboard</a>
        <a href="{{ $servicesIndex }}" class="block px-4 py-3 border-b">Services</a>
        <a href="{{ $ordersIndex }}" class="block px-4 py-3 border-b">Orders</a>
        <a href="{{ $usersIndex }}" class="block px-4 py-3 border-b">Users</a>
        <a href="{{ $plansIndex }}" class="block px-4 py-3">Plans</a>
      </div>
    </div>

    <!-- Content -->
    <main class="flex-1 md:ml-0 md:pl-0 w-full md:ms-64 md:ps-0">
      <div class="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-10">
        @if(session('ok'))
          <div class="mb-4 px-4 py-3 rounded bg-emerald-50 border border-emerald-200 text-emerald-700">{{ session('ok') }}</div>
        @endif
        @if($errors->any())
          <div class="mb-4 px-4 py-3 rounded bg-rose-50 border border-rose-200 text-rose-700">
            <ul class="list-disc ml-5">
              @foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach
            </ul>
          </div>
        @endif

        @yield('content')
      </div>
    </main>
  </div>
</body>
</html>
