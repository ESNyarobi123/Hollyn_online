@extends('admin.layout')
@section('title','Users')
@section('content')
<div class="flex items-center justify-between mb-6">
  <h1 class="text-2xl font-semibold">Users</h1>
</div>

<div class="bg-white border rounded-xl overflow-hidden">
  <table class="min-w-full text-sm">
    <thead class="bg-slate-50 text-slate-600">
      <tr>
        <th class="px-4 py-3 text-left">ID</th>
        <th class="px-4 py-3 text-left">Name</th>
        <th class="px-4 py-3 text-left">Email</th>
        <th class="px-4 py-3 text-left">Role</th>
        <th class="px-4 py-3 text-left">Joined</th>
        <th class="px-4 py-3"></th>
      </tr>
    </thead>
    <tbody>
      @foreach($users as $u)
      <tr class="border-t">
        <td class="px-4 py-3">{{ $u->id }}</td>
        <td class="px-4 py-3">{{ $u->name }}</td>
        <td class="px-4 py-3">{{ $u->email }}</td>
        <td class="px-4 py-3">{{ $u->role ?? 'user' }}</td>
        <td class="px-4 py-3">{{ $u->created_at }}</td>
        <td class="px-4 py-3 text-right">
          <a class="text-slate-700 hover:underline" href="{{ route('admin.users.show',$u) }}">View</a>
          <form action="{{ route('admin.users.destroy',$u) }}" method="post" class="inline" onsubmit="return confirm('Delete user?')">
            @csrf @method('DELETE')
            <button class="text-rose-600 hover:underline ml-3">Delete</button>
          </form>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>

<div class="mt-4">{{ $users->links() }}</div>
@endsection
