@extends('layouts.app')

@section('content')
<section class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-brand-cream via-white to-brand-cream p-8 md:p-12 shadow-soft">
  <div class="max-w-4xl">
    <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-brand-gold text-brand-ocean shadow-soft">Hollyn Hosting</span>
    <h1 class="mt-4 text-4xl md:text-5xl font-extrabold leading-tight text-brand-ocean">
      Host faster. Scale smarter. <span class="text-brand-emerald">Go live</span> in minutes.
    </h1>
    <p class="mt-3 text-brand-slate md:text-lg">
      Simple checkout na ZenoPay. Auto-provision ya <b>Webuzo</b>—pata cPanel link papo hapo.
    </p>
    <div class="mt-6 flex flex-wrap gap-3">
      <a href="{{ route('plans') }}" class="btn-primary">View Plans</a>
      @guest <a href="{{ route('register') }}" class="btn-gold">Create Account</a> @endguest
    </div>
  </div>
</section>

<section class="mt-10">
  <h2 class="heading mb-4">Featured Plans</h2>
  @if($plans->isEmpty())
    <div class="card">No plans yet. <a class="underline" href="{{ route('admin.plans.index') }}">Add plans in admin</a>.</div>
  @else
    <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
      @foreach($plans as $p)
        <div class="card flex flex-col">
          <div class="text-sm text-brand-slate">{{ $p->slug }}</div>
          <div class="mt-1 text-lg font-semibold text-brand-ocean">{{ $p->name }}</div>
          <div class="mt-2 text-3xl font-extrabold text-brand-emerald">TZS {{ number_format($p->price_tzs) }}</div>
          <a class="btn-primary mt-4" href="{{ route('checkout.show',$p) }}">Order {{ $p->name }}</a>
        </div>
      @endforeach
    </div>
  @endif
</section>
@endsection
