<!DOCTYPE html>
<html lang="en" x-data="{ open:true }">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title','Admin')</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root{
      --brand-ocean:#0f172a; /* fallback kama hauna tailwind config */
      --brand-cream:#f1f5f9;
      --brand-gold:#f59e0b;
    }
    body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,'Helvetica Neue',Arial}
    .text-brand-ocean{color:var(--brand-ocean)}
    .border-brand-cream{border-color:var(--brand-cream)}
    .bg-brand-cream{background-color:var(--brand-cream)}
    .thin-scroll::-webkit-scrollbar{width:8px;height:8px}
    .thin-scroll::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:8px}
    [x-cloak]{display:none!important}
  </style>
</head>
<body class="bg-slate-50">
@php
  // SALAMA dhidi ya RouteNotFoundException
  $adminHome     = \Illuminate\Support\Facades\Route::has('admin.index')          ? route('admin.index')          : url('/admin');
  $servicesIndex = \Illuminate\Support\Facades\Route::has('admin.services.index') ? route('admin.services.index') : '#';
  $ordersIndex   = \Illuminate\Support\Facades\Route::has('admin.orders.index')   ? route('admin.orders.index')   : '#';
  $usersIndex    = \Illuminate\Support\Facades\Route::has('admin.users.index')    ? route('admin.users.index')    : '#';
  $plansIndex    = \Illuminate\Support\Facades\Route::has('admin.plans.index')    ? route('admin.plans.index')    : '#';

  // Helper kwa active state by route name pattern
  $is = function($pattern){
    return request()->routeIs($pattern) ? 'bg-brand-cream text-brand-ocean font-semibold' : 'hover:bg-brand-cream/60';
  };
@endphp

<div class="min-h-screen flex">
  {{-- Sidebar --}}
  <aside :class="open ? 'w-64' : 'w-16'"
         class="transition-all duration-200 bg-white border-r border-brand-cream thin-scroll">
    <div class="h-16 flex items-center justify-between px-4">
      <a href="{{ $adminHome }}" class="font-extrabold text-brand-ocean">
        <span x-show="open" x-cloak>Hollyn Admin</span>
        <span x-show="!open" x-cloak>HA</span>
      </a>
      <button @click="open=!open"
              class="p-2 rounded-xl border border-brand-cream hover:bg-brand-cream/50"
              title="Toggle sidebar">≡</button>
    </div>

    <nav class="px-3 pb-6 text-sm space-y-1">
      <a href="{{ $adminHome }}" class="flex items-center gap-3 px-3 py-2 rounded {{ $is('admin.index') }}">
        <span>🏠</span><span x-show="open" x-cloak>Dashboard</span>
      </a>
      <a href="{{ $servicesIndex }}" class="flex items-center gap-3 px-3 py-2 rounded {{ request()->is('admin/services*') ? 'bg-brand-cream text-brand-ocean font-semibold' : 'hover:bg-brand-cream/60' }}">
        <span>🛠️</span><span x-show="open" x-cloak>Services</span>
      </a>
      <a href="{{ $ordersIndex }}" class="flex items-center gap-3 px-3 py-2 rounded {{ request()->is('admin/orders*') ? 'bg-brand-cream text-brand-ocean font-semibold' : 'hover:bg-brand-cream/60' }}">
        <span>🧾</span><span x-show="open" x-cloak>Orders</span>
      </a>
      <a href="{{ $usersIndex }}" class="flex items-center gap-3 px-3 py-2 rounded {{ request()->is('admin/users*') ? 'bg-brand-cream text-brand-ocean font-semibold' : 'hover:bg-brand-cream/60' }}">
        <span>👥</span><span x-show="open" x-cloak>Users</span>
      </a>
      <a href="{{ $plansIndex }}" class="flex items-center gap-3 px-3 py-2 rounded {{ request()->is('admin/plans*') ? 'bg-brand-cream text-brand-ocean font-semibold' : 'hover:bg-brand-cream/60' }}">
        <span>📦</span><span x-show="open" x-cloak>Plans</span>
      </a>
    </nav>
  </aside>

  {{-- Content --}}
  <main class="flex-1 min-w-0">
    <div class="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-10">
      @if(session('ok'))
        <div class="mb-4 px-4 py-3 rounded bg-emerald-50 border border-emerald-200 text-emerald-700">{{ session('ok') }}</div>
      @endif
      @if($errors->any())
        <div class="mb-4 px-4 py-3 rounded bg-rose-50 border border-rose-200 text-rose-700">
          <ul class="list-disc ml-5">
            @foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach
          </ul>
        </div>
      @endif

      @yield('content')
    </div>
  </main>
</div>
</body>
</html>
