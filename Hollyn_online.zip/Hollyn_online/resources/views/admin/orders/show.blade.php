@if(in_array($order->status,['paid','complete']) && (!$order->service || $order->service->status!=='active'))
  <form method="post" action="{{ route('admin.services.reprovision', optional($order->service) ?? $order->service()->firstOrCreate(['user_id'=>$order->user_id,'plan_id'=>$order->plan_id,'order_id'=>$order->id])) }}">
    @csrf
    <button class="px-3 py-2 rounded-lg border">Provision now</button>
  </form>
@endif
