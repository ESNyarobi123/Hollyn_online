@extends('admin.layout')
@section('title','Services')

@section('content')
<div class="flex items-center justify-between mb-6">
  <div>
    <h1 class="text-2xl font-semibold">Services</h1>
    <p class="text-slate-500">Manage provisioned hosting accounts</p>
  </div>
  <form method="get" class="flex gap-2">
    <input type="text" name="search" value="{{ request('search') }}" placeholder="Search domain/username" class="px-3 py-2 border rounded-lg">
    <select name="status" class="px-3 py-2 border rounded-lg">
      <option value="">All statuses</option>
      @foreach(['provisioning','active','suspended','cancelled'] as $st)
        <option value="{{ $st }}" @selected(request('status')===$st)>{{ ucfirst($st) }}</option>
      @endforeach
    </select>
    <button class="px-4 py-2 rounded-lg border">Filter</button>
  </form>
</div>

{{-- KPIs --}}
<div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
  <div class="card"><div class="text-sm text-slate-500">Total</div><div class="text-2xl font-bold">{{ $stats['total'] ?? $services->total() }}</div></div>
  <div class="card"><div class="text-sm text-slate-500">Active</div><div class="text-2xl font-bold text-emerald-600">{{ $stats['active'] ?? '—' }}</div></div>
  <div class="card"><div class="text-sm text-slate-500">Provisioning</div><div class="text-2xl font-bold">{{ $stats['provisioning'] ?? '—' }}</div></div>
  <div class="card"><div class="text-sm text-slate-500">Suspended</div><div class="text-2xl font-bold text-amber-600">{{ $stats['suspended'] ?? '—' }}</div></div>
</div>

<div class="bg-white border rounded-xl overflow-hidden">
  <table class="min-w-full text-sm">
    <thead class="bg-slate-50 text-slate-600">
      <tr>
        <th class="px-4 py-3 text-left">ID</th>
        <th class="px-4 py-3 text-left">User</th>
        <th class="px-4 py-3 text-left">Plan</th>
        <th class="px-4 py-3 text-left">Domain</th>
        <th class="px-4 py-3 text-left">Username</th>
        <th class="px-4 py-3 text-left">Status</th>
        <th class="px-4 py-3"></th>
      </tr>
    </thead>
    <tbody>
      @forelse($services as $s)
      @php
        $status = $s->status ?? 'provisioning';
        $badge  = match($status) {
          'active'       => 'bg-emerald-50 text-emerald-700',
          'provisioning' => 'bg-amber-50 text-amber-700',
          'suspended'    => 'bg-rose-50 text-rose-700',
          default        => 'bg-gray-200 text-gray-700',
        };
      @endphp
      <tr class="border-t">
        <td class="px-4 py-3">{{ $s->id }}</td>
        <td class="px-4 py-3">{{ optional(optional($s->order)->user)->name ?? '—' }}</td>
        <td class="px-4 py-3">{{ optional($s->plan)->name ?? '—' }}</td>
        <td class="px-4 py-3">{{ $s->domain ?? '—' }}</td>
        <td class="px-4 py-3">{{ $s->panel_username ?? '—' }}</td>
        <td class="px-4 py-3">
          <span class="px-2 py-0.5 rounded-full text-xs font-semibold {{ $badge }}">
            {{ ucfirst($status) }}
          </span>
        </td>
        <td class="px-4 py-3 text-right">
          <a href="{{ route('admin.services.show',$s) }}" class="text-blue-600 hover:underline">View</a>
        </td>
      </tr>
      @empty
      <tr><td colspan="7" class="px-4 py-6 text-center text-slate-500">No services found.</td></tr>
      @endforelse
    </tbody>
  </table>
</div>

<div class="mt-4">{{ $services->links() }}</div>
@endsection
