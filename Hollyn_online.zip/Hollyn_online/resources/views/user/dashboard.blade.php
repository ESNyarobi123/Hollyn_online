@extends('layouts.app')
@section('title','My Dashboard')

@section('content')
<style>
  :root{
    --ocean:#0f172a;--cream:#e2e8f0;--soft:#f8fafc;--gold:#f59e0b;--emerald:#059669;--slate:#475569;--ring:rgba(15,23,42,.12);
    --bg:#f6f7fb;--card:#ffffff;--line:#eef2f7;--indigo:#4f46e5;--rose:#e11d48;--cyan:#0891b2;--violet:#7c3aed;
  }
  .dash{display:flex;gap:0;min-height:calc(100vh - 80px);}
  .sidebar{position:relative;background:var(--card);border-right:1px solid var(--line);width:264px;transition:width .2s ease, transform .25s ease;box-shadow:0 10px 40px rgba(2,6,23,.04)}
  .sidebar header{display:flex;align-items:center;gap:.6rem;padding:1rem 1rem .75rem;border-bottom:1px solid var(--line)}
  .sb-brand{display:flex;align-items:center;gap:.5rem;font-weight:800;color:var(--ocean)}
  .sb-brand .logo{display:grid;place-items:center;width:36px;height:36px;border-radius:.8rem;background:linear-gradient(135deg,#0b1220,var(--ocean));color:#fff}
  .sb-nav{padding:.75rem}
  .sb-nav a{display:flex;align-items:center;gap:.75rem;padding:.62rem .75rem;border-radius:.75rem;color:#0b1220;font-weight:600;border:1px solid transparent}
  .sb-nav a:hover{background:var(--soft);border-color:var(--line)}
  .sb-nav a.active{background:#0f172a;color:#fff;border-color:#0f172a}
  .sb-nav .icon{width:18px;height:18px}
  .sb-footer{margin-top:auto;padding:1rem;border-top:1px solid var(--line)}
  .collapse-btn{position:absolute;right:.75rem;top:.85rem;border-radius:.6rem;border:1px solid var(--line);padding:.35rem .5rem;background:#fff}
  .main{flex:1;background:var(--bg)}
  .topbar{position:sticky;top:0;z-index:10;background:rgba(255,255,255,.7);backdrop-filter:blur(8px);border-bottom:1px solid var(--line)}
  .topbar-wrap{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.9rem 1rem}
  .burger{display:inline-flex;align-items:center;gap:.5rem;border:1px solid var(--line);border-radius:.75rem;padding:.5rem .7rem;background:#fff}
  .content{padding:1rem;max-width:1152px;margin:0 auto}

  .btn{display:inline-flex;align-items:center;gap:.5rem;padding:.55rem 1rem;border-radius:1rem;border:1px solid transparent;font-weight:700;transition:.15s;cursor:pointer}
  .btn:focus{outline:none;box-shadow:0 0 0 4px var(--ring)}
  .btn-primary{background:var(--ocean);color:#fff}.btn-primary:hover{transform:translateY(-1px)}
  .btn-gold{background:var(--gold);color:#111827}.btn-gold:hover{filter:brightness(1.03)}
  .btn-ghost{border-color:var(--cream);color:var(--ocean);background:#fff}.btn-ghost:hover{background:#f8fafc}
  .card{background:var(--card);border:1px solid var(--line);border-radius:1rem;padding:1rem}
  .krow{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.9rem}
  @media (min-width:1024px){.krow{grid-template-columns:repeat(4,minmax(0,1fr))}}
  .tiny{font-size:.82rem;color:var(--slate)}
  .big{font-size:2rem;font-weight:800;color:#0b1220}
  .pill{display:inline-flex;align-items:center;padding:.2rem .6rem;border-radius:999px;font-size:.72rem;font-weight:800}
  .pill-ok{background:#ecfdf5;color:#065f46}.pill-warn{background:#fff7ed;color:#92400e}.pill-gray{background:#e5e7eb;color:#374151}
  .field{display:inline-flex;align-items:center;gap:.4rem;background:#f8fafc;border:1px solid var(--line);padding:.25rem .55rem;border-radius:.75rem}
  table{width:100%;border-collapse:collapse}
  th,td{padding:.65rem .75rem;border-top:1px solid var(--line);vertical-align:middle;font-size:.92rem}
  thead th{background:#f8fafc;color:#334155;font-weight:700;border-top:none}

  .kpi{border-radius:1rem;padding:1rem;color:#fff}
  .k1{background:linear-gradient(135deg,var(--emerald),#22c55e)}
  .k2{background:linear-gradient(135deg,var(--indigo),#3b82f6)}
  .k3{background:linear-gradient(135deg,var(--gold),#f97316);color:#111827}
  .k4{background:linear-gradient(135deg,var(--violet),#8b5cf6)}

  .sidebar.collapsed{width:84px}
  .sidebar.collapsed .text{display:none}
  .sidebar.collapsed .sb-footer{display:none}

  @media (max-width:1023px){
    .sidebar{position:fixed;inset:0 auto 0 0;transform:translateX(-100%);height:100vh}
    .sidebar.open{transform:translateX(0)}
    .scrim{position:fixed;inset:0;background:rgba(2,6,23,.35);backdrop-filter:blur(1px);opacity:0;pointer-events:none;transition:.2s}
    .scrim.show{opacity:1;pointer-events:auto}
  }
</style>

@php
  $services   = collect($services ?? []);
  $ordersList = collect($recentOrders ?? ($orders ?? []));
  $s          = $stats ?? [];
  $provOrder  = $provisionableOrder ?? null;

  $fmt = fn($n)=> is_numeric($n) ? number_format((float)$n) : ($n ?? '0');
  $abbr = function($n){
    $n = (float)($n ?? 0);
    if ($n >= 1_000_000_000) return round($n/1_000_000_000,2).'B';
    if ($n >= 1_000_000)     return round($n/1_000_000,2).'M';
    if ($n >= 1_000)         return round($n/1_000,1).'K';
    return number_format($n);
  };
  $get = function($row,$key=null){ if(is_null($row))return null; if(is_null($key))return $row; return is_object($row)?($row->{$key}??null):(is_array($row)?($row[$key]??null):null); };

  $safeRoute = function(string $name, array $params = []) {
    try { return \Illuminate\Support\Facades\Route::has($name) ? route($name, $params) : null; }
    catch (\Throwable $e) { return null; }
  };

  $plansUrl      = $safeRoute('plans');
  $panelUrlSSO   = $safeRoute('me.panel'); // kama unayo SSO route
  $statusUrl     = $safeRoute('me.services.status');
  $provLatestUrl = $safeRoute('me.services.provisionLatest');
  $provWithIdUrl = ($provOrder && \Illuminate\Support\Facades\Route::has('me.services.provision'))
                   ? route('me.services.provision', $provOrder->id) : null;

  $servicesIndex = $safeRoute('me.services.index') ?? $safeRoute('admin.services.index');
  $ordersIndex   = $safeRoute('me.orders.index')   ?? $safeRoute('admin.orders.index');

  $hasActive = ($s['services_active'] ?? 0) > 0
               || $services->contains(fn($x)=>strtolower((string)$get($x,'status'))==='active');

  $activeSvc = $services->first(function($svc){
    return strtolower((string)\Illuminate\Support\Arr::get((array)$svc,'status', data_get($svc,'status',''))) === 'active'
           && (data_get($svc,'enduser_url') || data_get($svc,'panel_url'));
  });
  $panelHrefCandidate = data_get($activeSvc,'enduser_url') ?? data_get($activeSvc,'panel_url');
  $finalPanelHref = $panelUrlSSO ?? $panelHrefCandidate;

  $spark = is_array($revenueLast7 ?? null) ? $revenueLast7 : [12,18,15,21,19,26,30];
  $max = max($spark ?: [1]); $w = 180; $h = 42;
  $pts=[]; foreach($spark as $i=>$v){ $x = (count($spark)>1 ? $i/(count($spark)-1) : 0) * $w; $y = $h - ($max>0 ? ($v/$max)*$h : 0); $pts[]="$x,$y"; }
  $lastSpark = $spark[count($spark)-1] ?? 0;

  $ns1 = (string) config('services.webuzo.ns1');
  $ns2 = (string) config('services.webuzo.ns2');

  $hasProvisionAction = (bool)($provWithIdUrl || $provLatestUrl);
@endphp

<div class="dash">
  {{-- ============ SIDEBAR ============ --}}
  <aside id="sidebar" class="sidebar">
    <button class="collapse-btn" type="button" id="collapseBtn" title="Collapse/Expand">
      <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M15 19l-7-7 7-7" stroke="#0f172a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
    <header>
      <div class="sb-brand">
        <div class="logo">CP</div>
        <div class="text">Control Panel</div>
      </div>
    </header>
    <nav class="sb-nav">
      @php
         $nav = [
             ['name'=>'Dashboard','icon'=>'M3 12h18M3 6h18M3 18h18','url'=>$safeRoute('me.dashboard') ?? '#','active'=>\Illuminate\Support\Facades\Request::routeIs('me.dashboard')],
             ['name'=>'My Services','icon'=>'M4 6h16v12H4z','url'=>$servicesIndex ?? '#','active'=>\Illuminate\Support\Facades\Request::is('*/services*')],
             ['name'=>'Orders','icon'=>'M6 7h12M6 12h12M6 17h12','url'=>$ordersIndex ?? '#','active'=>\Illuminate\Support\Facades\Request::is('*/orders*')],
             ['name'=>'Plans','icon'=>'M12 3l9 4-9 4-9-4 9-4z','url'=>$plansUrl ?? '#','active'=>\Illuminate\Support\Facades\Request::routeIs('plans')],
            ];
      @endphp
      @foreach($nav as $it)
        <a href="{{ $it['url'] }}" class="{{ $it['active'] ? 'active' : '' }}">
          <svg class="icon" viewBox="0 0 24 24" fill="none"><path d="{{ $it['icon'] }}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
          <span class="text">{{ $it['name'] }}</span>
        </a>
      @endforeach
    </nav>
    <div class="sb-footer">
      <div class="tiny" style="margin-bottom:.4rem;color:#0b1220;font-weight:700;">Storage</div>
      <div class="tiny" style="margin-bottom:.35rem">Used 24.6 GB of 100 GB</div>
      <div style="height:8px;background:#eef2f7;border-radius:999px;overflow:hidden">
        <div style="height:100%;width:24.6%;background:linear-gradient(90deg,#0b1220,#0f172a)"></div>
      </div>
    </div>
  </aside>

  {{-- ============ MAIN ============ --}}
  <div class="main">
    <div class="topbar">
      <div class="topbar-wrap">
        <button class="burger" id="burgerBtn" type="button">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 6h18M3 12h18M3 18h18" stroke="#0f172a" stroke-width="2" stroke-linecap="round"/></svg>
          <span class="tiny" style="color:#0f172a;font-weight:700">Menu</span>
        </button>

        <div style="display:flex;align-items:center;gap:.6rem">
          @if($hasActive && $finalPanelHref)
            <a href="{{ $finalPanelHref }}" id="openPanelTop" class="btn btn-primary" title="Open your hosting control panel">Open Panel</a>
          @elseif($hasProvisionAction)
            <form method="POST" action="{{ $provWithIdUrl ?: $provLatestUrl }}">
              @csrf
              <button class="btn btn-gold" id="finishBtnTop">Finish setup</button>
            </form>
          @elseif($plansUrl)
            <a href="{{ $plansUrl }}" class="btn btn-primary">Choose a plan</a>
          @endif
        </div>
      </div>
    </div>

    <div class="content">
      {{-- Flash / Errors --}}
      @if(session('status'))
        <div class="mb-4 card" style="border-color:#bbf7d0;background:#ecfdf5;color:#065f46" id="statusBanner">{{ session('status') }}</div>
      @else
        <div id="statusBanner" class="mb-4 card" style="display:none"></div>
      @endif
      @if($errors->any())
        <div class="mb-4 card" style="border-color:#fecaca;background:#fef2f2;color:#991b1b">
          {{ $errors->first() }}
        </div>
      @endif

      {{-- KPIs --}}
      <div class="krow mb-6">
        <div class="kpi k1">
          <div class="tiny" style="color:#e7fff1">Active Services</div>
          <div class="big" style="color:#fff">{{ $fmt($s['services_active'] ?? 0) }}</div>
          <div class="tiny" style="color:#e7fff1">Provisioning: {{ $fmt($s['services_provisioning'] ?? 0) }}</div>
        </div>
        <div class="kpi k2">
          <div class="tiny" style="color:#e8f0ff">Orders (Paid)</div>
          <div class="big" style="color:#fff">{{ $fmt($s['orders_paid'] ?? 0) }}</div>
          <div class="tiny" style="color:#e8f0ff">Total: {{ $fmt($s['orders_total'] ?? 0) }}</div>
        </div>
        <div class="kpi k3">
          <div class="tiny">Revenue (TZS)</div>
          <div class="big">TZS {{ $fmt($s['revenue_tzs'] ?? 0) }}</div>
          <div class="tiny">Last payment: {{ $s['last_payment_at'] ?? '—' }}</div>
        </div>
        <div class="kpi k4">
          <div class="tiny" style="color:#efe9ff">Last 7 days</div>
          <div style="display:flex;align-items:flex-end;gap:.75rem">
            <div class="big" style="color:#fff">TZS {{ $abbr($lastSpark) }}</div>
            <svg width="{{ $w }}" height="{{ $h }}" viewBox="0 0 {{ $w }} {{ $h }}">
              <polyline fill="none" stroke="#fff" stroke-width="2" points="{{ implode(' ', $pts) }}"/>
            </svg>
          </div>
          <div class="tiny" style="color:#efe9ff">Trend preview</div>
        </div>
      </div>

      {{-- My Panel (first active service) --}}
      @if($activeSvc)
        @php
          $pDomain = data_get($activeSvc,'domain','—');
          $pUser   = data_get($activeSvc,'webuzo_username') ?: data_get($activeSvc,'panel_username') ?: '—';
          $pUrl    = $finalPanelHref;
        @endphp
        <div class="card mb-6" style="background:linear-gradient(135deg,#0b1220,#0f172a);color:#fff;border:0">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap">
            <div>
              <div style="font-size:1.15rem;font-weight:800">My Panel</div>
              <div class="tiny" style="color:#c7d2fe">Quick access to your hosting control panel</div>
            </div>
            @if($pUrl)<a href="{{ $pUrl }}" class="btn btn-gold" id="openPanelCard">Open Panel</a>@endif
          </div>

          <div style="display:grid;grid-template-columns:repeat(1,minmax(0,1fr));gap:.6rem;margin-top:.9rem">
            <div class="field" style="background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.15);color:#fff">Domain: <strong>{{ $pDomain }}</strong> <button type="button" class="tiny" onclick="copyTxt('{{ $pDomain }}')">Copy</button></div>
            <div class="field" style="background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.15);color:#fff">Username: <strong id="uName">{{ $pUser }}</strong> <button type="button" class="tiny" onclick="copyTxt(document.getElementById('uName').innerText)">Copy</button></div>
            @if($ns1 || $ns2)
            <div class="field" style="background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.15);color:#fff">Nameservers: <strong>{{ $ns1 ?: '—' }}</strong> <strong style="margin-left:.4rem">{{ $ns2 ?: '' }}</strong></div>
            @endif
          </div>
        </div>
      @endif

      {{-- Hosting Services --}}
      <div class="card mb-6">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <h2 style="color:#0b1220;font-weight:800">My Hosting</h2>
          @if($servicesIndex) <a class="btn btn-ghost" href="{{ $servicesIndex }}">All Services</a> @endif
        </div>

        @if($services->isEmpty())
          <div class="py-8" style="text-align:center;color:var(--slate)">
            You don’t have an active hosting service yet.
            <div class="mt-3">
              @if($hasProvisionAction)
                <form method="POST" action="{{ $provWithIdUrl ?: $provLatestUrl }}">
                  @csrf
                  <button class="btn btn-primary" id="finishBtnEmpty">Finish setup</button>
                </form>
              @elseif($plansUrl)
                <a href="{{ $plansUrl }}" class="btn btn-primary">Choose a plan</a>
              @endif
            </div>
          </div>
        @else
          <div class="mt-3" style="border-top:1px solid var(--line)">
            @foreach($services as $svc)
              @php
                $status = strtolower((string) ($get($svc,'status') ?? 'provisioning'));
                $active = $status === 'active';
                $plan   = data_get($svc,'plan.name') ?? data_get($svc,'plan_name') ?? data_get($svc,'plan_title') ?? '—';
                $domain = $get($svc,'domain') ?: '—';
                $uname  = $get($svc,'webuzo_username') ?: $get($svc,'panel_username') ?: '—';
                $orderId= data_get($svc,'order.id');
                $badge  = $active ? 'pill pill-ok' : ($status==='provisioning' ? 'pill pill-warn' : 'pill pill-gray');
              @endphp
              <div style="display:flex;gap:1rem;align-items:center;justify-content:space-between;padding:.9rem 0;border-bottom:1px solid var(--line)">
                <div>
                  <div style="font-weight:800;color:#0b1220">
                    {{ $plan }} <span class="{{ $badge }}" style="margin-left:.5rem">{{ ucfirst($status) }}</span>
                  </div>
                  <div class="tiny" style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.35rem">
                    <span class="field">Domain: <strong>{{ $domain }}</strong> <button type="button" class="tiny" onclick="copyTxt('{{ $domain }}')">Copy</button></span>
                    <span class="field">Username: <strong>{{ $uname }}</strong> <button type="button" class="tiny" onclick="copyTxt('{{ $uname }}')">Copy</button></span>
                  </div>
                </div>
                <div style="display:flex;gap:.5rem;flex-wrap:wrap">
                  @if($active && $finalPanelHref)
                    <a href="{{ $finalPanelHref }}" class="btn btn-primary">Open Panel</a>
                  @elseif($status === 'provisioning')
                    <span class="btn btn-ghost">Provisioning…</span>
                  @else
                    @if($hasProvisionAction)
                      <form method="POST" action="{{ $provWithIdUrl ?: $provLatestUrl }}">
                        @csrf
                        <button class="btn btn-gold">Provision</button>
                      </form>
                    @else
                      <span class="btn btn-ghost">Pending</span>
                    @endif
                  @endif

                  @if($orderId && \Illuminate\Support\Facades\Route::has('order.summary'))
                    <a href="{{ route('order.summary', $orderId) }}" class="btn btn-ghost">Order #{{ $orderId }}</a>
                  @endif
                </div>
              </div>
            @endforeach
          </div>
        @endif
      </div>

      {{-- Recent Orders --}}
      <div class="card">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <h2 style="color:#0b1220;font-weight:800">Recent Orders</h2>
          @if($ordersIndex) <a href="{{ $ordersIndex }}" class="btn btn-ghost">View all</a> @endif
        </div>

        <div class="mt-3" style="overflow-x:auto">
          <table>
            <thead>
              <tr>
                <th class="text-left">Order</th>
                <th class="text-left">Plan</th>
                <th class="text-left">Price</th>
                <th class="text-left">Status</th>
                <th class="text-left">Created</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              @forelse($ordersList as $o)
                @php
                  $oid    = $get($o,'id');
                  $pname  = data_get($o,'plan.name') ?? $get($o,'plan_name') ?? $get($o,'plan_title') ?? '—';
                  $price  = (int) ($get($o,'price_tzs') ?? 0);
                  $st     = strtolower((string) ($get($o,'status') ?? 'pending'));
                  $created= $get($o,'created_at') ?: '—';
                  $stBadge= in_array($st,['paid','active','complete','succeeded']) ? 'pill pill-ok' : ($st==='failed'?'pill pill-gray':'pill pill-warn');
                  $viewUrl= ($oid && \Illuminate\Support\Facades\Route::has('order.summary')) ? route('order.summary',$oid) : null;
                @endphp
                <tr>
                  <td>#{{ $oid ?: '—' }}</td>
                  <td>{{ $pname }}</td>
                  <td>TZS {{ number_format($price) }}</td>
                  <td><span class="{{ $stBadge }}">{{ ucfirst($st) }}</span></td>
                  <td>{{ $created }}</td>
                  <td>@if($viewUrl)<a class="btn btn-ghost" href="{{ $viewUrl }}">View</a>@endif</td>
                </tr>
              @empty
                <tr><td colspan="6" style="text-align:center;color:var(--slate);padding:1.5rem 0">No orders yet.</td></tr>
              @endforelse
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="scrim" id="scrim"></div>

<script>
  const sb   = document.getElementById('sidebar');
  const scr  = document.getElementById('scrim');
  const burger = document.getElementById('burgerBtn');
  const collapseBtn = document.getElementById('collapseBtn');

  try{
    const collapsed = localStorage.getItem('sb-collapsed') === '1';
    if (collapsed && window.matchMedia('(min-width:1024px)').matches) sb.classList.add('collapsed');
  }catch(_){}

  const openDrawer = ()=>{ sb.classList.add('open'); scr.classList.add('show'); }
  const closeDrawer= ()=>{ sb.classList.remove('open'); scr.classList.remove('show'); }

  burger?.addEventListener('click', ()=>{
    if (window.matchMedia('(max-width:1023px)').matches){
      if (sb.classList.contains('open')) closeDrawer(); else openDrawer();
    } else {
      sb.classList.toggle('collapsed');
      try{ localStorage.setItem('sb-collapsed', sb.classList.contains('collapsed') ? '1' : '0'); }catch(_){}
    }
  });
  scr?.addEventListener('click', closeDrawer);

  collapseBtn?.addEventListener('click', ()=>{
    sb.classList.toggle('collapsed');
    try{ localStorage.setItem('sb-collapsed', sb.classList.contains('collapsed') ? '1' : '0'); }catch(_){}
  });

  function copyTxt(text){
    if (navigator.clipboard && window.isSecureContext){
      navigator.clipboard.writeText(text);
    }else{
      const ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
    }
  }

  (function(){
    const statusUrl = @json($statusUrl);
    const banner = document.getElementById('statusBanner');
    const openPanelTop  = document.getElementById('openPanelTop');
    const openPanelCard = document.getElementById('openPanelCard');

    if (!statusUrl) return;

    let stop = false;
    async function poll(){
      if (stop) return;
      try{
        const r = await fetch(statusUrl, {headers:{'Accept':'application/json'}});
        if(!r.ok) return; const s = await r.json();

        if (banner) banner.style.display = 'block';

        if ((s.active ?? 0) > 0){
          if (banner){
            banner.style.background='#ecfdf5'; banner.style.color='#065f46';
            banner.textContent='Service is Active. Opening Panel is now available.';
          }
          // show “Open Panel” CTAs if were hidden
          if (openPanelTop)  openPanelTop.style.display = '';
          if (openPanelCard) openPanelCard.style.display = '';

          // stop polling and refresh page once to load fresh service details
          stop = true;
          setTimeout(()=>location.reload(), 800);
          return;
        }

        if ((s.provisioning ?? 0) > 0 || (s.requested ?? 0) > 0){
          if (banner){
            banner.style.background='#eff6ff'; banner.style.color='#1e40af';
            banner.textContent='Provisioning… This will switch to Active shortly.';
          }
        } else if ((s.failed ?? 0) > 0){
          if (banner){
            banner.style.background='#fef2f2'; banner.style.color='#991b1b';
            banner.textContent='Provisioning failed. Please try again or contact support.';
          }
        }
      }catch(e){
        // ignore transient errors
      }
    }
    poll();
    const iv = setInterval(()=>{ if(!stop) poll(); else clearInterval(iv); }, 5000);
  })();
</script>
@endsection
