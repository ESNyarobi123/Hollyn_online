
<?php $__env->startSection('title','Orders'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-6">
  <h1 class="text-2xl font-semibold">Orders</h1>
  <a href="<?php echo e(route('admin.orders.create')); ?>" class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">+ New Order</a>
</div>

<form method="get" class="mb-4 flex gap-3 items-center">
  <select name="status" class="px-3 py-2 border rounded-lg">
    <option value="">All statuses</option>
    <?php $__currentLoopData = ['pending','paid','failed','active','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($st); ?>" <?php if(request('status')===$st): echo 'selected'; endif; ?>><?php echo e(ucfirst($st)); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <button class="px-4 py-2 rounded-lg border">Filter</button>
</form>

<div class="bg-white border rounded-xl overflow-hidden">
  <table class="min-w-full text-sm">
    <thead class="bg-slate-50 text-slate-600">
      <tr>
        <th class="px-4 py-3 text-left">ID</th>
        <th class="px-4 py-3 text-left">User</th>
        <th class="px-4 py-3 text-left">Plan</th>
        <th class="px-4 py-3 text-left">Price (TZS)</th>
        <th class="px-4 py-3 text-left">Status</th>
        <th class="px-4 py-3 text-left">Created</th>
        <th class="px-4 py-3"></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr class="border-t">
        <td class="px-4 py-3"><?php echo e($o->id); ?></td>
        <td class="px-4 py-3"><?php echo e(optional($o->user)->name); ?></td>
        <td class="px-4 py-3"><?php echo e(optional($o->plan)->name); ?></td>
        <td class="px-4 py-3 font-medium"><?php echo e(number_format((int)$o->price_tzs)); ?></td>
        <td class="px-4 py-3"><span class="px-2 py-1 rounded text-xs bg-slate-100"><?php echo e($o->status); ?></span></td>
        <td class="px-4 py-3"><?php echo e($o->created_at); ?></td>
        <td class="px-4 py-3 text-right">
          <a class="text-blue-600 hover:underline" href="<?php echo e(route('admin.orders.edit',$o)); ?>">Edit</a>
          <a class="text-slate-600 hover:underline ml-3" href="<?php echo e(route('admin.orders.show',$o)); ?>">View</a>
          <form action="<?php echo e(route('admin.orders.destroy',$o)); ?>" method="post" class="inline" onsubmit="return confirm('Delete order?')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="text-rose-600 hover:underline ml-3">Delete</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<div class="mt-4"><?php echo e($orders->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>