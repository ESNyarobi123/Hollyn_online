
<?php $__env->startSection('title','Services'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-6">
  <div>
    <h1 class="text-2xl font-semibold">Services</h1>
    <p class="text-slate-500">Manage provisioned hosting accounts</p>
  </div>
  <form method="get" class="flex gap-2">
    <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search domain/username" class="px-3 py-2 border rounded-lg">
    <select name="status" class="px-3 py-2 border rounded-lg">
      <option value="">All statuses</option>
      <?php $__currentLoopData = ['provisioning','active','suspended','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($st); ?>" <?php if(request('status')===$st): echo 'selected'; endif; ?>><?php echo e(ucfirst($st)); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="px-4 py-2 rounded-lg border">Filter</button>
  </form>
</div>


<div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
  <div class="card"><div class="text-sm text-slate-500">Total</div><div class="text-2xl font-bold"><?php echo e($stats['total'] ?? $services->total()); ?></div></div>
  <div class="card"><div class="text-sm text-slate-500">Active</div><div class="text-2xl font-bold text-emerald-600"><?php echo e($stats['active'] ?? '—'); ?></div></div>
  <div class="card"><div class="text-sm text-slate-500">Provisioning</div><div class="text-2xl font-bold"><?php echo e($stats['provisioning'] ?? '—'); ?></div></div>
  <div class="card"><div class="text-sm text-slate-500">Suspended</div><div class="text-2xl font-bold text-amber-600"><?php echo e($stats['suspended'] ?? '—'); ?></div></div>
</div>

<div class="bg-white border rounded-xl overflow-hidden">
  <table class="min-w-full text-sm">
    <thead class="bg-slate-50 text-slate-600">
      <tr>
        <th class="px-4 py-3 text-left">ID</th>
        <th class="px-4 py-3 text-left">User</th>
        <th class="px-4 py-3 text-left">Plan</th>
        <th class="px-4 py-3 text-left">Domain</th>
        <th class="px-4 py-3 text-left">Username</th>
        <th class="px-4 py-3 text-left">Status</th>
        <th class="px-4 py-3"></th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <?php
        $status = $s->status ?? 'provisioning';
        $badge  = match($status) {
          'active'       => 'bg-emerald-50 text-emerald-700',
          'provisioning' => 'bg-amber-50 text-amber-700',
          'suspended'    => 'bg-rose-50 text-rose-700',
          default        => 'bg-gray-200 text-gray-700',
        };
      ?>
      <tr class="border-t">
        <td class="px-4 py-3"><?php echo e($s->id); ?></td>
        <td class="px-4 py-3"><?php echo e(optional(optional($s->order)->user)->name ?? '—'); ?></td>
        <td class="px-4 py-3"><?php echo e(optional($s->plan)->name ?? '—'); ?></td>
        <td class="px-4 py-3"><?php echo e($s->domain ?? '—'); ?></td>
        <td class="px-4 py-3"><?php echo e($s->panel_username ?? '—'); ?></td>
        <td class="px-4 py-3">
          <span class="px-2 py-0.5 rounded-full text-xs font-semibold <?php echo e($badge); ?>">
            <?php echo e(ucfirst($status)); ?>

          </span>
        </td>
        <td class="px-4 py-3 text-right">
          <a href="<?php echo e(route('admin.services.show',$s)); ?>" class="text-blue-600 hover:underline">View</a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr><td colspan="7" class="px-4 py-6 text-center text-slate-500">No services found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<div class="mt-4"><?php echo e($services->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/admin/services/index.blade.php ENDPATH**/ ?>