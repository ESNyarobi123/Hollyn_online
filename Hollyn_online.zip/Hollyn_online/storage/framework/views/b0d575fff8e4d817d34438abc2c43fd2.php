<?php if(in_array($order->status,['paid','complete']) && (!$order->service || $order->service->status!=='active')): ?>
  <form method="post" action="<?php echo e(route('admin.services.reprovision', optional($order->service) ?? $order->service()->firstOrCreate(['user_id'=>$order->user_id,'plan_id'=>$order->plan_id,'order_id'=>$order->id]))); ?>">
    <?php echo csrf_field(); ?>
    <button class="px-3 py-2 rounded-lg border">Provision now</button>
  </form>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>