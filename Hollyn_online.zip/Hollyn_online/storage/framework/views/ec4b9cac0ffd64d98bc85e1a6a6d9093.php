

<?php $__env->startSection('content'); ?>
  
  <div class="flex items-center justify-between mb-6">
    <div>
      <h2 class="heading">Hosting Plans</h2>
      <p class="text-brand-slate mt-1">Chagua mpango unaokufaa — lipa kwa ZenoPay, provision automatic, kisha nenda cPanel mara moja.</p>
    </div>
    <a href="<?php echo e(route('home')); ?>" class="hidden sm:inline-flex btn-gold">Back to Home</a>
  </div>

  
  <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $isPopular = $p->slug === 'hollyn-boost';
        $isMax     = $p->slug === 'hollyn-max';
        $preview   = collect($p->features ?? [])->take(4);
      ?>

      <div class="relative group">
        
        <?php if($isPopular): ?>
          <div class="absolute -top-2 left-3 z-10">
            <span class="px-2 py-0.5 rounded-full text-xs font-semibold bg-brand-gold text-brand-ocean shadow-soft">Most Popular</span>
          </div>
        <?php endif; ?>

        <div class="card h-full transition-transform duration-200 group-hover:-translate-y-1">
          
          <div class="flex items-center justify-between">
            <div>
              <div class="text-sm text-brand-slate"><?php echo e($p->slug); ?></div>
              <h3 class="text-xl font-semibold text-brand-ocean"><?php echo e($p->name); ?></h3>
            </div>
            <div class="rounded-xl px-2 py-1 text-xs font-medium <?php echo e($p->is_active ? 'bg-brand-cream text-brand-ocean' : 'bg-gray-200 text-gray-600'); ?>">
              <?php echo e($p->is_active ? 'Active' : 'Inactive'); ?>

            </div>
          </div>

          
          <div class="mt-3">
            <div class="text-3xl font-extrabold text-brand-emerald">TZS <?php echo e(number_format($p->price_tzs)); ?></div>
            <div class="text-xs text-brand-slate">per month</div>
          </div>

          
          <ul class="mt-4 space-y-2">
            <?php $__empty_1 = true; $__currentLoopData = $preview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li class="flex items-start gap-2">
                <span class="badge shrink-0 mt-0.5">✓</span>
                <span class="text-sm">
                  <span class="text-brand-ocean font-medium"><?php echo e($k); ?>:</span>
                  <span class="text-brand-slate">
                    <?php echo e($isMax && str_contains(Str::lower($v), 'unlimited') ? '∞ Unlimited' : $v); ?>

                  </span>
                </span>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <li class="text-sm text-brand-slate">Optimized PHP • SSD • Free SSL</li>
            <?php endif; ?>
          </ul>

          
          <div class="mt-5 flex items-center gap-3">
            <a class="btn-primary flex-1 justify-center" href="<?php echo e(route('checkout.show', $p)); ?>">
              Order <?php echo e($p->name); ?>

            </a>
            <button type="button"
                    onclick="document.getElementById('feat-<?php echo e($p->id); ?>')?.showModal()"
                    class="px-3 py-2 rounded-xl border border-brand-cream text-sm text-brand-ocean hover:bg-brand-cream/60">
              View all
            </button>
          </div>
        </div>
      </div>

      
      <dialog id="feat-<?php echo e($p->id); ?>" class="rounded-2xl shadow-soft backdrop:bg-black/40 w-11/12 max-w-2xl">
        <form method="dialog" class="p-0 m-0">
          <div class="p-5 border-b border-brand-cream/60 flex items-center justify-between">
            <div>
              <div class="text-sm text-brand-slate"><?php echo e($p->slug); ?></div>
              <div class="text-lg font-semibold text-brand-ocean"><?php echo e($p->name); ?> — <span class="text-brand-emerald">TZS <?php echo e(number_format($p->price_tzs)); ?></span></div>
            </div>
            <button class="px-3 py-1.5 rounded-lg bg-brand-ocean text-white">Close</button>
          </div>
        </form>
        <div class="p-5">
          <?php $all = collect($p->features ?? []); ?>
          <?php if($all->isEmpty()): ?>
            <p class="text-brand-slate text-sm">No features provided for this plan.</p>
          <?php else: ?>
            <div class="grid sm:grid-cols-2 gap-4">
              <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-3 rounded-xl bg-brand-cream/60">
                  <div class="text-xs text-brand-slate"><?php echo e($k); ?></div>
                  <div class="text-brand-ocean font-semibold">
                    <?php echo e(($p->slug === 'hollyn-max' && Str::lower($v) === 'unlimited') ? '∞ Unlimited' : $v); ?>

                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>
          <div class="mt-5">
            <a class="btn-gold" href="<?php echo e(route('checkout.show', $p)); ?>">Continue with <?php echo e($p->name); ?></a>
          </div>
        </div>
      </dialog>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  
  <div class="mt-10 card">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
      <div>
        <div class="text-lg font-semibold text-brand-ocean">Compare features across all plans</div>
        <p class="text-brand-slate text-sm">Angalia tofauti zote kwa macho: disk, bandwidth, emails, DBs, domains na mengine.</p>
      </div>
      <a href="<?php echo e(route('plans')); ?>#compare" class="btn-primary">Open Comparison</a>
    </div>
  </div>

  
  <div id="compare" class="mt-8">
    <?php
      $featureOrder = [
        'Disk Space Quota',
        'Max Inodes',
        'Monthly Bandwidth',
        'Max FTP Accounts',
        'Max Email Accounts',
        'Max Quota per Mailbox',
        'Max MySQL Databases',
        'Max Subdomains',
        'Max Parked (Aliases)',
        'Max Addon Domains',
        'Hourly Email Limit (domain)',
        'Max % Failed/Deferred / hr',
      ];
      $bySlug = $plans->keyBy('slug');
      $cols   = ['hollyn-lite','hollyn-grow','hollyn-boost','hollyn-max'];
    ?>

    <div class="card overflow-x-auto">
      <h3 class="heading mb-4">Full Comparison</h3>
      <table class="min-w-full text-sm">
        <thead>
          <tr class="text-left">
            <th class="py-3 pr-6 text-brand-ocean">Feature</th>
            <?php $__currentLoopData = $cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $pl = $bySlug->get($slug); ?>
              <th class="py-3 px-4">
                <?php if($pl): ?>
                  <div class="font-semibold text-brand-ocean"><?php echo e($pl->name); ?></div>
                  <div class="text-brand-emerald font-bold">TZS <?php echo e(number_format($pl->price_tzs)); ?></div>
                <?php else: ?>
                  <div class="text-brand-slate">—</div>
                <?php endif; ?>
              </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $featureOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t">
              <td class="py-2 pr-6 text-brand-ocean"><?php echo e($feat); ?></td>
              <?php $__currentLoopData = $cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $pl  = $bySlug->get($slug);
                  $val = $pl?->features[$feat] ?? '—';
                  $isUnlimited = ($slug === 'hollyn-max') && (Str::lower((string)$val) === 'unlimited');
                ?>
                <td class="py-2 px-4 <?php echo e($isUnlimited ? 'text-brand-emerald font-semibold' : 'text-brand-slate'); ?>">
                  <?php echo e($isUnlimited ? '∞ Unlimited' : $val); ?>

                </td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/public/plans.blade.php ENDPATH**/ ?>