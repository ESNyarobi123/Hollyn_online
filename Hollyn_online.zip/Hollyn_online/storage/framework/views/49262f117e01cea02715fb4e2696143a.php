
<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto card">
  <h2 class="heading mb-2">Order Summary</h2>
  <p>Status: <span class="badge"><?php echo e($order->status); ?></span></p>
  <p class="mt-2">Plan: <b><?php echo e($order->plan->name); ?></b> — TZS <?php echo e(number_format($order->price_tzs)); ?></p>
  <p>Domain: <?php echo e($order->domain ?: '—'); ?></p>

  <?php if($order->service): ?>
    <div class="mt-4">
      <h3 class="font-semibold mb-1">Service</h3>
      <p>State: <span class="badge"><?php echo e($order->service->status); ?></span></p>
      <?php if($order->service->status==='active' && $order->service->enduser_url): ?>
        <a class="btn-primary mt-3" target="_blank" href="<?php echo e($order->service->enduser_url); ?>">Go to cPanel</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/public/order.blade.php ENDPATH**/ ?>