
<?php $__env->startSection('title','Create Order'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-semibold mb-6">Create Order</h1>

<form action="<?php echo e(route('admin.orders.store')); ?>" method="post" class="bg-white border rounded-xl p-6 space-y-4 max-w-2xl">
  <?php echo csrf_field(); ?>
  <div>
    <label class="block text-sm mb-1">User</label>
    <select name="user_id" class="w-full border rounded-lg px-3 py-2" required>
      <option value="">-- Choose User --</option>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

  <div>
    <label class="block text-sm mb-1">Plan</label>
    <select name="plan_id" class="w-full border rounded-lg px-3 py-2" required>
      <option value="">-- Choose Plan --</option>
      <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

  <div class="grid md:grid-cols-2 gap-4">
    <div>
      <label class="block text-sm mb-1">Price (TZS)</label>
      <input type="number" name="price_tzs" class="w-full border rounded-lg px-3 py-2" min="0" required>
    </div>
    <div>
      <label class="block text-sm mb-1">Status</label>
      <select name="status" class="w-full border rounded-lg px-3 py-2" required>
        <?php $__currentLoopData = ['pending','paid','failed','active','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($st); ?>"><?php echo e(ucfirst($st)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>

  <div>
    <label class="block text-sm mb-1">Notes</label>
    <textarea name="notes" rows="4" class="w-full border rounded-lg px-3 py-2" placeholder="Optional admin notes..."></textarea>
  </div>

  <div class="flex items-center gap-3">
    <button class="px-5 py-2.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700">Create</button>
    <a href="<?php echo e(route('admin.orders.index')); ?>" class="px-4 py-2 rounded-lg border">Cancel</a>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LARAVEL PROJECT\Hollyn_online\resources\views/admin/orders/create.blade.php ENDPATH**/ ?>