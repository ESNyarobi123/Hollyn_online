<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Service;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DashboardController extends Controller
{
    public function index()
    {
        $uid = Auth::id();
        if (!$uid) return redirect()->route('login');

        // Normalized statuses
        $PAID     = ['paid','active','complete','succeeded'];
        $ACTIVE   = ['active','running'];
        $PROV     = ['provisioning','pending_provision','pending','queued'];
        $FAILED   = ['failed','cancelled','canceled'];

        // Base queries
        $ordersUser = Order::query()->where('user_id', $uid);

        $servicesBase = Service::query();
        if (Schema::hasColumn('services','user_id')) {
            $servicesBase->where('user_id', $uid);
        } else {
            $servicesBase->whereHas('order', fn ($q) => $q->where('user_id', $uid));
        }

        // Aggregates
        $ordersTotal   = (clone $ordersUser)->count();
        $ordersPaid    = (clone $ordersUser)->whereIn('status', $PAID)->count();
        $ordersFailed  = (clone $ordersUser)->whereIn('status', $FAILED)->count();

        $servicesActive       = (clone $servicesBase)->whereIn('status', $ACTIVE)->count();
        $servicesProvisioning = (clone $servicesBase)->whereIn('status', $PROV)->count();

        $revenueTzs = (int) (clone $ordersUser)
            ->whereIn('status', $PAID)
            ->sum(DB::raw('COALESCE(price_tzs,0)'));

        $lastPaidOrder = (clone $ordersUser)
            ->whereIn('status', $PAID)
            ->latest('id')
            ->select('id','price_tzs','created_at','plan_id')
            ->first();

        // Lists
        $services = (clone $servicesBase)
            ->with(['plan:id,name,slug','order:id,user_id,plan_id,status'])
            ->latest('id')
            ->get();

        $recentOrders = (clone $ordersUser)
            ->with(['plan:id,name'])
            ->latest('id')
            ->take(6)
            ->get();

        // Latest PAID order without service (Finish setup)
        if (Schema::hasTable('services')) {
            // Prefer Eloquent relation check
            $provisionableOrder = (clone $ordersUser)
                ->with(['service','plan:id,name'])
                ->whereIn('status', $PAID)
                ->whereDoesntHave('service')
                ->latest('id')
                ->first();
        } else {
            // If services table doesn't exist, no provisioning possible
            $provisionableOrder = null;
        }

        // Panel URL from latest active service (if column exists)
        $panelUrl = null;
        if (Schema::hasColumn('services','enduser_url')) {
            $latestActive  = (clone $servicesBase)
                ->whereIn('status', $ACTIVE)
                ->latest('id')
                ->first();
            $panelUrl = $latestActive->enduser_url ?? null;
        }

        // Stats
        $stats = [
            'orders_total'          => $ordersTotal,
            'orders_paid'           => $ordersPaid,
            'orders_failed'         => $ordersFailed,
            'services_active'       => $servicesActive,
            'services_provisioning' => $servicesProvisioning,
            'revenue_tzs'           => $revenueTzs,
            'last_payment_at'       => $lastPaidOrder?->created_at,
            'last_payment_amount'   => (int)($lastPaidOrder->price_tzs ?? 0),
        ];

        // CTA helpers
        $cta = [
            'show_finish_setup' => (bool) $provisionableOrder,
            'show_upgrade'      => !$provisionableOrder && $servicesActive === 0,
            'panel_url'         => $panelUrl,
        ];

        return view('user.dashboard', [
            'stats'               => $stats,
            'services'            => $services,
            'recentOrders'        => $recentOrders,
            'hasActiveService'    => $servicesActive > 0,
            'provisionableOrder'  => $provisionableOrder,
            'cta'                 => $cta,
        ]);
    }
}
