<?php

namespace App\Jobs;

use App\Models\Order;
use App\Models\Service;
use App\Support\WebuzoPackageResolver;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Cache\Repository as CacheRepository;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\Middleware\WithoutOverlapping;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

class ProvisionWebuzoAccount implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $orderId;

    public int $tries = 3;
    public int $timeout = 120;

    /** Idempotency window ya uniqueness ya job (sekunde) */
    public int $uniqueFor = 900; // 15 min

    public function __construct(int $orderId)
    {
        $this->orderId = $orderId;
        $this->onQueue('provisioning');
    }

    public function uniqueId(): string
    {
        return 'provision:order:'.$this->orderId;
    }

    /** Ensure ShouldBeUnique uses a deterministic cache store (e.g. redis) */
    public function uniqueVia(): CacheRepository
    {
        // Badilisha 'redis' kulingana na config/cache.php yako
        return Cache::store(config('queue.unique_cache', 'redis'));
    }

    public function backoff(): array
    {
        return [15, 60, 180];
    }

    public function middleware(): array
    {
        return [
            (new WithoutOverlapping('prov-webuzo-order-'.$this->orderId))
                ->releaseAfter(20)
                ->expireAfter(180),
        ];
    }

    public function handle(): void
    {
        $order = Order::with(['user','plan','service'])->find($this->orderId);
        if (!$order) {
            Log::warning("ProvisionWebuzoAccount: Order {$this->orderId} not found.");
            return;
        }

        $paidStates = ['paid','succeeded','complete','completed','success','active'];
        if (!in_array(Str::lower((string) $order->status), $paidStates, true)) {
            // no log spam; just skip
            return;
        }

        if ($order->service && in_array($order->service->status, ['provisioning','active'], true)) {
            // already in progress or done
            return;
        }

        $user = $order->user;
        $plan = $order->plan;
        if (!$user || !$plan) {
            Log::warning("ProvisionWebuzoAccount: Missing user/plan for order {$order->id}.");
            return;
        }

        $package = (string) (WebuzoPackageResolver::resolve($plan)['package'] ?? config('services.webuzo.default_package', 'starter'));

        $baseUsername = $this->makeBaseUsername($user->name ?? $user->email ?? 'user');
        $username     = $baseUsername . Str::lower(Str::random(2));
        $password     = $this->makeStrongPassword();

        $domain = $this->normalizeDomain(
            $order->domain ?: (Str::slug($user->name ?? 'site') . '.hollyn.site')
        );

        $service = Service::updateOrCreate(
            ['order_id' => $order->id],
            [
                'plan_slug'                => $plan->slug ?? null,
                'domain'                   => $domain,
                'enduser_url'              => (string) config('services.webuzo.enduser_url'),
                'webuzo_username'          => $username,
                'webuzo_temp_password_enc' => Crypt::encryptString($password),
                'status'                   => 'provisioning',
            ]
        );

        $base = rtrim((string) config('services.webuzo.api_url'), '/');
        $path = ltrim((string) config('services.webuzo.create_path', 'index.php?api=json&act=add_user'), '/');
        $url  = $base . '/' . $path;

        $timeout   = (int) config('services.webuzo.timeout', 90);
        $cto       = (int) config('services.webuzo.connect_timeout', 10);
        $verifySsl = (bool) config('services.webuzo.verify_ssl', false);
        $useBasic  = (bool) config('services.webuzo.use_basic_auth', true);

        $payload = [
            'user'    => $username,
            'pass'    => $password,
            'email'   => $user->email,
            'package' => $package,
        ];

        try {
            $req = Http::timeout($timeout)->connectTimeout($cto)
                ->asForm()
                ->withHeaders(['Accept' => 'application/json']);

            if ($useBasic && config('services.webuzo.admin_user') && config('services.webuzo.admin_pass')) {
                $req = $req->withBasicAuth(
                    (string) config('services.webuzo.admin_user'),
                    (string) config('services.webuzo.admin_pass')
                );
            }
            if (!$verifySsl) {
                $req = $req->withoutVerifying();
            }
            if ($key = config('services.webuzo.api_key')) {
                $req = $req->withHeaders(['Authorization' => 'Bearer '.$key]);
            }

            $resp = $req->post($url, $payload);

            // Username conflict → jaribu tena na jina lingine
            if ($resp->status() === 409 || $this->hasUsernameError($resp)) {
                for ($i = 0; $i < 2; $i++) {
                    $username        = $baseUsername . Str::lower(Str::random(3));
                    $payload['user'] = $username;
                    $service->webuzo_username = $username;
                    $service->save();

                    $resp = $req->post($url, $payload);
                    if ($resp->successful() && !$this->hasError($resp)) break;
                }
            }

            if (!$resp->successful()) {
                throw new \RuntimeException("Webuzo HTTP error: {$resp->status()} - " . Str::limit((string)$resp->body(), 600));
            }

            $data = $this->safeJson($resp);
            if ($this->hasError($resp, $data)) {
                $msg = isset($data['error']) ? json_encode($data['error'], JSON_UNESCAPED_SLASHES) : 'unknown error';
                throw new \RuntimeException("Webuzo API error: {$msg}");
            }

            // Success
            $service->status = 'active';
            $service->save();

            $order->status = 'active';
            $order->save();

            Log::info("Provisioned Webuzo (package={$package}) for order {$order->id} as user={$username}");
        } catch (Throwable $e) {
            // Kama tayari service iko active, usirequeue
            $service->refresh();
            if ($service->status === 'active') {
                Log::warning("ProvisionWebuzoAccount: received exception but service is active; swallow. msg=".$e->getMessage());
                return;
            }

            Log::error("ProvisionWebuzoAccount failed for order {$order->id}: " . $e->getMessage(), [
                'url'     => $url ?? null,
                'payload' => $this->mask($payload ?? []),
            ]);

            // requeue kidogo tu
            $this->release(30);
            throw $e;
        }
    }

    public function failed(Throwable $e): void
    {
        try {
            $order = Order::with('service')->find($this->orderId);
            if ($order?->service && $order->service->status !== 'active') {
                $order->service->status = 'failed';
                $order->service->save();
            }
        } catch (Throwable) {
            // ignore
        }
        Log::error("ProvisionWebuzoAccount permanently failed for order {$this->orderId}: {$e->getMessage()}");
    }

    // -------- helpers (bila mabadiliko makubwa) --------
    protected function makeBaseUsername(string $seed): string
    {
        $base = Str::of($seed)->ascii()->lower()->replace(' ','')->replaceMatches('/[^a-z0-9]/','')->value();
        $base = $base ?: 'user';
        if (!ctype_alpha($base[0] ?? '')) $base = 'u'.$base;
        return Str::limit($base, 9, '');
    }

    protected function makeStrongPassword(): string
    {
        return Str::random(10) . 'aA1!';
    }

    protected function normalizeDomain(string $domain): string
    {
        $d = strtolower(trim($domain));
        $d = preg_replace('#^https?://#', '', $d);
        $d = preg_replace('#/.*$#', '', $d);
        $d = preg_replace('/\s+/', '', $d);
        return $d;
    }

    protected function safeJson($resp): array
    {
        try { return $resp->json() ?? []; } catch (\Throwable) { return []; }
    }

    protected function hasError($resp, ?array $data = null): bool
    {
        $data ??= $this->safeJson($resp);
        if (isset($data['error']) && !empty($data['error'])) return true;
        if (isset($data['done']) && (int)$data['done'] === 0) return true;
        return false;
    }

    protected function hasUsernameError($resp): bool
    {
        $data = $this->safeJson($resp);
        if (!isset($data['error'])) return false;
        $err = is_array($data['error']) ? json_encode($data['error']) : (string) $data['error'];
        return stripos($err, 'username') !== false || stripos($err, 'user already exists') !== false;
    }

    protected function mask(array $payload): array
    {
        $masked = $payload;
        if (isset($masked['pass'])) $masked['pass'] = '***';
        if (isset($masked['user_passwd'])) $masked['user_passwd'] = '***';
        if (isset($masked['cnf_user_passwd'])) $masked['cnf_user_passwd'] = '***';
        return $masked;
    }
}
