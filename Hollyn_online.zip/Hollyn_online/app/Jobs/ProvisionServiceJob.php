<?php

namespace App\Jobs;

use App\Models\Service;
use App\Models\ProvisioningLog;
use App\Services\WebuzoApi;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Cache\Repository as CacheRepository;
use Illuminate\Contracts\Queue\ShouldBeUniqueUntilProcessing;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\Middleware\RateLimited;
use Illuminate\Queue\Middleware\WithoutOverlapping;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Throwable;

class ProvisionServiceJob implements ShouldQueue, ShouldBeUniqueUntilProcessing
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** Mara za kujaribu kabla ya fail */
    public int $tries = 3;

    /** Muda wa juu (sekunde) kwa run moja */
    public int $timeout = 120;

    /** Queue maalum */
    public string $queue = 'provisioning';

    /** Uniqueness window (sekunde) hadi job ianze kuchakatwa */
    public int $uniqueFor = 900; // 15 min

    public function __construct(public int $serviceId) {}

    /** Job iwe unique hadi processing ianze */
    public function uniqueId(): string
    {
        return 'provision-service-'.$this->serviceId;
    }

    /** Tumia cache store sahihi kwa uniqueness (mf. redis) */
    public function uniqueVia(): CacheRepository
    {
        return Cache::store(config('queue.unique_cache', 'redis'));
    }

    /** Backoff kati ya retries */
    public function backoff(): array
    {
        return [10, 60, 180];
    }

    /** Epuka overlap + rate limit ya API ya nje */
    public function middleware(): array
    {
        return [
            // Key ya WithoutOverlapping iwe ya service ili job za service hiyo zisiwe concurrent
            (new WithoutOverlapping('prov-svc-'.$this->serviceId))
                ->releaseAfter(30)  // zikirushwa nje, jaribu tena baada ya 30s
                ->expireAfter(300), // lock ya overlap i-expire worst-case baada ya 5min
            new RateLimited('webuzo-provision'),
        ];
    }

    /**
     * Provision the service on Webuzo.
     */
    public function handle(WebuzoApi $webuzo): void
    {
        // Throttle ya “run” (kupunguza marudio ndani ya dirisha fupi hata kama dispatch ilitokea mara kadhaa)
        $runKey = "svc:prov:run:{$this->serviceId}";
        if (!Cache::add($runKey, 1, now()->addMinutes(2))) {
            // Ilisha-run hivi karibuni → ruka kimya
            return;
        }

        // Lock ya ziada (beyond middleware) kuzuia concurrency cross-worker
        $lock = Cache::lock("svc:prov:lock:{$this->serviceId}", 300);
        if (!$lock->get()) {
            $this->release(15);
            return;
        }

        try {
            // Chukua service kwa lock ya DB ili kuzuia race ya kuset status/credentials
            /** @var Service $service */
            $service = Service::query()
                ->with(['order.user','order.plan'])
                ->whereKey($this->serviceId)
                ->lockForUpdate()
                ->firstOrFail();

            // Kama tayari ipo active/provisioning → ruka
            if (in_array($service->status, ['active','provisioning'], true)) {
                return;
            }

            // Mark provisioning (idempotent)
            $service->status = 'provisioning';
            if (Schema::hasColumn('services', 'last_provision_attempt_at')) {
                $service->last_provision_attempt_at = now();
            }
            $service->save();
            $this->log($service, 'status_update', ['status' => 'provisioning'], ['ok' => true]);

            // ---------- Credentials ----------
            $order = $service->order;
            $user  = $order?->user;

            $email = $order?->customer_email
                ?? $user?->email
                ?? ('user'.$service->id.'@example.local');

            $username = $this->makeUsername($email, (int) $service->id);
            $password = $this->makeStrongPassword();

            // Package/plan
            $planSlug = $service->plan_slug
                ?? $order?->plan?->slug
                ?? config('services.webuzo.default_package', 'starter');

            // Domain fallback
            $domain = $service->domain ?: ($username.'.local');

            // ---------- Call Webuzo (create user) ----------
            $this->log($service, 'create_user', [
                'email' => $email,
                'username' => $username,
                'package' => $planSlug,
                'domain' => $domain,
            ]);

            // NB: Ikiwa WebuzoApi yako ina “external idempotency” param,
            // unaweza kupitisha externalId => "svc-{$service->id}" ndani ya createUser().
            $res1 = $webuzo->createUser(
                email:    $email,
                username: $username,
                password: $password,
                package:  (string) $planSlug,
                limits:   [] // tumia config/webuzo_packages ukihitaji
            );
            $this->log($service, 'create_user_response', [], $res1);

            if (!($res1['ok'] ?? false)) {
                // Je, ni username exists lakini user tayari “ipo”? mark as success idempotently.
                $bodyStr = json_encode($res1['body'] ?? []);
                if (stripos($bodyStr, 'exists') !== false || stripos($bodyStr, 'already') !== false) {
                    // Tutaendelea kama success (idempotent create)
                } else {
                    throw new \RuntimeException('Webuzo createUser failed: '.$bodyStr);
                }
            }

            // ---------- Optional: add domain ----------
            if (!empty($service->domain)) {
                $this->log($service, 'add_domain', ['username' => $username, 'domain' => $service->domain]);
                $res2 = $webuzo->addDomain($username, $service->domain);
                $this->log($service, 'add_domain_response', [], $res2);
                // best-effort; usi-break provisioning isipokuwa unataka iwe strict
            }

            // ---------- Persist success ----------
            DB::transaction(function () use ($service, $order, $username, $password) {
                $service->webuzo_username          = $username;
                $service->webuzo_temp_password_enc = encrypt($password);
                $service->enduser_url              = (string) config('services.webuzo.enduser_url');
                $service->status                   = 'active';
                if (Schema::hasColumn('services', 'last_provisioned_at')) {
                    $service->last_provisioned_at = now();
                }
                $service->save();

                if ($order) {
                    // Weka status ya order active/complete kulingana na flow
                    $order->status = 'active';
                    $order->save();
                }
            });

            $this->log($service, 'status_update', ['status' => 'active'], ['ok' => true]);
        } catch (Throwable $e) {
            // Kama kwa wakati huu service tayari imewekwa active, usirequeue (swallow)
            $svc = Service::find($this->serviceId);
            if ($svc && $svc->status === 'active') {
                Log::warning("ProvisionServiceJob: exception swallowed; service already active", [
                    'service_id' => $this->serviceId,
                    'msg' => $e->getMessage(),
                ]);
                return;
            }

            $this->logRaw($this->serviceId, 'error', ['message' => $e->getMessage()]);
            throw $e; // acha retries zifanye kazi
        } finally {
            optional($lock)->release();
        }
    }

    /** Mark failed after all retries */
    public function failed(Throwable $e): void
    {
        try {
            $service = Service::find($this->serviceId);
            if ($service && $service->status !== 'active') {
                $service->status = 'failed';
                if (Schema::hasColumn('services', 'last_failed_at')) {
                    $service->last_failed_at = now();
                }
                $service->save();

                $this->logRaw($service->id, 'final_failed', [
                    'message' => $e->getMessage(),
                ]);
            }
        } catch (Throwable) {
            // silent
        }
    }

    /** ===================== Helpers ===================== */

    protected function makeUsername(string $email, int $suffixId): string
    {
        $local = strstr($email, '@', true) ?: 'user';
        $clean = strtolower(preg_replace('/[^a-z0-9]/', '', $local));
        if ($clean === '' || !ctype_alpha($clean[0])) $clean = 'u'.$clean; // must start with a letter
        $base  = Str::limit($clean, 10, '');
        return $base.$suffixId; // ex: johnsmith42
    }

    protected function makeStrongPassword(): string
    {
        return Str::random(12).'aA1!'; // lower+upper+digit+symbol
    }

    protected function log(Service $service, string $step, array $request = [], $response = null): void
    {
        ProvisioningLog::create([
            'service_id' => $service->id,
            'step'       => $step,
            'request'    => json_encode($request, JSON_UNESCAPED_SLASHES),
            'response'   => is_array($response) ? json_encode($response, JSON_UNESCAPED_SLASHES) : (string)($response ?? ''),
            'success'    => true,
        ]);
    }

    protected function logRaw(int $serviceId, string $step, array $payload = []): void
    {
        ProvisioningLog::create([
            'service_id' => $serviceId,
            'step'       => $step,
            'request'    => json_encode(['service_id' => $serviceId], JSON_UNESCAPED_SLASHES),
            'response'   => json_encode($payload, JSON_UNESCAPED_SLASHES),
            'success'    => false,
        ]);
    }
}
